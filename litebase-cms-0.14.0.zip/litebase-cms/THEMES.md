# Cum se face o temă pentru LiteBase CMS

O temă este un folder în `themes/`. Cel mai simplu început: din administrare, **Teme → Duplică** pe tema „Implicită”,
apoi modifici fișierele din `themes/<numele-temei>/` și activezi tema din listă.

## Fișiere

Obligatorii:

| Fișier       | Rol |
|--------------|-----|
| `layout.php` | structura comună a paginii HTML: `<head>`, antet, meniu, `<?= $content ?>`, subsol |
| `page.php`   | conținutul unei pagini obișnuite (se pune în `$content`) |
| `home.php`   | conținutul paginii de start |
| `404.php`    | pagina „negăsită” |
| `style.css`  | stilurile temei |

Opționale (dacă lipsesc, se folosesc cele din tema „default”):
`_content.php` (textul paginii, galeria, fișierele), `_slider.php` (un slider), `_slider_js.php` (scriptul sliderelor),
`theme.json` (informații afișate în administrare), orice alte imagini, fonturi, scripturi.

`theme.json`:

```json
{ "name": "Numele temei", "version": "1.0.0", "author": "Numele tău", "description": "O frază." }
```

## Variabile disponibile

În `layout.php`:
`$lang`, `$siteName`, `$tagline`, `$footer` (HTML editat din Setări), `$menu` (lista de pagini din meniu; fiecare are `title`,
`id`, `children`), `$allLangs` (cod => nume), `$isAdmin`, `$page` (rândul paginii sau `null` la 404), `$currentId`,
`$metaTitle`, `$metaDesc`, `$metaKeywords`, `$canonical`, `$ogImage`, `$noindex`, `$content` (HTML-ul produs de `page.php`/`home.php`).

În `page.php` / `home.php` (+ cele de mai sus): `$page` (`title`, `content`...), `$images` (galerie), `$aligned` (imagini
aliniate stânga/dreapta/centru), `$docs` (fișiere de descărcat), `$topSlider` (HTML-ul sliderului de la începutul paginii, poate fi gol).

## Funcții utile

`e($text)` escapare HTML · `url('cale')` adresă către un fișier (css, imagini) · `route('ro/')` adresă către o pagină ·
`page_url($pagina)` · `theme_css()` stilul cu culorile din „Aspect” (se pune într-un `<style>` în `<head>`) ·
`theme_url('style.css')` adresa unui fișier al temei · `footer_map()` datele hărții din subsol · `cfg('credit')`.

## Reguli

- Păstrează `<?= theme_css() ?>` în `<head>` dacă vrei ca pagina „Aspect” să funcționeze; culorile sunt variabile CSS
  (`--text`, `--link`, `--card-bg`...). O temă poate să le ignore și să-și definească propriile culori.
- Pentru ca blocurile din editor să arate bine (carduri `.cards/.card`, secțiuni `.section`, containere `.container`,
  imagini `.att-left/right/center`, `.embed`, `.slider`), copiază-le din `style.css` al temei „default”.
- Fișierele `.php` ale temei nu pot fi deschise direct din browser; le include CMS-ul.
- Instalarea din .zip: fișierele pot fi la rădăcina arhivei sau într-un singur folder. Se acceptă doar fișiere de tip
  php, css, js, json, md, txt, html, svg, imagini și fonturi.
- **Atenție:** o temă rulează cod PHP. Instalează doar teme de încredere.

## Texte traduse

Textele fixe din temă se scriu `<?= e(t('Main menu')) ?>` (cheia este textul în engleză; `t('Slide %d', $n)` acceptă argumente ca sprintf). Traducerile stau în `lang/<cod>.php`; ce lipsește apare în engleză. Pe site, `t()` folosește limba paginii afișate.
