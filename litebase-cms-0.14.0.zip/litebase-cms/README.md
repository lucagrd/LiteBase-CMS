# LiteBase CMS

Versiunea curentă: vezi fișierul `VERSION` (semver). Modificările sunt în `CHANGELOG.md`.

CMS simplu în PHP + SQLite (fără MySQL), inspirat de Quick.Cms.

## Pornire locală (cel mai simplu)

```
cd litebase-cms
php -S localhost:8000 router.php
```

Apoi deschide http://localhost:8000/admin/ — la prima vizită îți creezi contul de administrator.
Site-ul public este la http://localhost:8000/

Cerințe: PHP 8.0+ cu extensiile `pdo_sqlite` și `mbstring` (opțional `gd`, pentru micșorarea automată a imaginilor).

## Pe hosting (Apache)

Încarcă tot folderul pe server (în rădăcină sau într-un subfolder) și deschide `/admin/`.
`.htaccess` se ocupă de URL-urile prietenoase. Folderele `data/` și `uploads/` trebuie să fie scriibile.
Pe Nginx, redirecționează tot ce nu e fișier real către `index.php` și blochează accesul la `data/`, `lib/` și `config.php`.

## Ce poți face din administrare

- **Pagini**: arbore cu subpagini, ordonare cu ↑↓, editor vizual (cu buton Accordion), afișare/ascundere, includere în meniu
- **Imagini și fișiere** atașate fiecărei pagini (galerie + linkuri de descărcare); imaginile mari sunt micșorate automat la 1600 px
- **Pagini**: programare (vizibilă de la/până la), cuvinte cheie SEO, imagini aliniate stânga/dreapta/centru, carduri, secțiuni și containere în editor
- **Aspect**: culori pentru fiecare element, culori de hover/click pentru linkuri și subliniere, previzualizare live și teme gata făcute
- **Slidere**: fiecare slider are propria pagină, cu imaginile lui (încărcare multiplă); îl pui în orice pagină, la început sau în text; săgeți, puncte și glisare pe telefon
- **Teme**: instalezi, duplici și activezi teme; ghid în `THEMES.md`
- **Butoane** în conținut (text, link, colțuri rotunjite sau drepte), stilate din Aspect
- **Interfață multilingvă**: administrarea folosește limba implicită a siteului; fișiere de limbă în `lang/` (ro, en incluse), poți adăuga propria limbă pornind de la `lang/en.php`
- **Limbi nelimitate**: adaugi/ștergi oricând; conținutul rămâne și revine la readăugare
- **Iframe-uri** (hărți, video) oriunde în conținut
- **Subsol editabil** (carduri, secțiuni, imagini, slidere), pe limbă
- **Hartă Google Maps** în subsol, cu coordonate, zoom și înălțime setabile
- **URL Rewriting** (adrese curate) activat implicit, se poate opri din Setări
- **SEO**: URL-uri prietenoase (cu diacriticele transformate), titlu și descriere meta per pagină, `sitemap.xml`, `robots.txt`, adresă canonică, taguri Open Graph
- **Limbi**: română, engleză, germană, franceză, spaniolă, italiană, maghiară; conținut separat pe fiecare
- **Setări**: nume site, slogan, text subsol, schimbare parolă

## Structura

```
index.php            site-ul public (rutare, SEO)
admin/               panoul de administrare
lib/bootstrap.php    baza de date, autentificare, încărcări
themes/default/      tema (layout.php, home.php, page.php, style.css)
lang/                fișiere de limbă (ro.php, en.php …; vezi lang/README.md)
data/cms.sqlite      baza de date (se creează singură) — fă copii de siguranță aici
uploads/             fișierele încărcate — fă copii de siguranță și aici
config.php           setări tehnice (limită upload, semnătură)
```

Culorile se schimbă din administrare (Aspect). Pentru modificări de structură, editează fișierele din `themes/default/`; culorile sunt variabile CSS definite în `lib/theme.php`.

## Securitate

Parole cu hash, protecție CSRF pe toate formularele, încărcări doar pe listă de extensii (cu verificarea conținutului pentru imagini),
fără execuție de scripturi în `uploads/`. Conținutul paginilor este HTML scris de administrator și nu este filtrat.
