# Language files

Each file is named after the language code (`ro.php`, `en.php`, `pl.php`, `fr.php`, `pt-br.php` …)
and returns an array: **the key is the English text, the value is its translation.**

## Make your own language

1. Copy `en.php` to `<code>.php` (e.g. `pl.php`).
2. Change `'_name'` to the language's own name (e.g. `'Polski'`).
3. Translate the values on the right of `=>`. Keep `%s`, `%d` and HTML tags (`<code>…</code>`) unchanged.
4. In the admin: **Settings → Languages**, add the language to the site and choose it as the default —
   the whole admin switches to it immediately.

A text missing from your file is shown in English, so a partial translation works too.
The pages and other content you write are never translated or changed: they stay in the language they were written in.

Note: the editor's own built-in texts (TinyMCE) are not part of these files.
