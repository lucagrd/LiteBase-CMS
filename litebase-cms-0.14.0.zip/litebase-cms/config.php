<?php
// Setări tehnice. Restul setărilor (nume site, limbi etc.) se schimbă din panoul de administrare.
return [
    'max_upload_mb' => 10,

    // Semnătura din subsolul paginilor
    'credit'        => true,
    'credit_name'   => 'Luca Gradisteanu',
    'credit_email'  => 'luca.gradisteanu@gmail.com',
];
