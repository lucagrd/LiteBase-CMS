<?php
// Router pentru serverul PHP încorporat:  php -S localhost:8000 router.php
// (Pe Apache/hosting se folosește .htaccess, acest fișier nu e necesar.)

$path = rawurldecode((string)parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

// Protejează folderele interne și configurarea
if (preg_match('~^/(data|lib|lang)(/|$)|^/config\.php$|^/router\.php$|^/themes/.*\.php$~i', $path)) {
    http_response_code(403);
    exit('Acces interzis');
}
// Nu executa scripturi din uploads
if (preg_match('~^/uploads/.*\.(php|phtml|phar)$~i', $path)) {
    http_response_code(403);
    exit('Acces interzis');
}

$file = __DIR__ . $path;
if ($path !== '/' && is_file($file)) {
    return false;                       // fișier real (css, imagini, admin/index.php ...)
}
if (is_dir($file) && is_file(rtrim($file, '/') . '/index.php') && $path !== '/') {
    return false;                       // ex. /admin/
}

require __DIR__ . '/index.php';
