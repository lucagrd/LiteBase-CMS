# Istoric versiuni

Versionare [semver](https://semver.org/lang/ro/): `MAJOR.MINOR.PATCH`.
Cât timp MAJOR este 0, structura internă (inclusiv baza de date) se poate mai schimba între versiuni MINOR.
Versiunea curentă se află în fișierul `VERSION` și apare în coltul administrării.

## [0.14.0] — 2026-10-31

### Adăugat
- Butoane în conținut (pagini, carduri, secțiuni, containere, subsol): butonul „Buton” din editor cere textul, linkul, colțuri rotunjite da/nu și deschidere în filă nouă; se poate modifica oricând apăsând „Buton” cu cursorul pe el
- Pagina Aspect: grupul „Butoane” (fundal, text, contur, culori la hover, raza colțurilor, grosimea conturului), cu exemplu în previzualizare; presetările de culori le setează și pe ele
- Textele noi sunt în `lang/ro.php` și `lang/en.php`

### Modificat
- Semnătura din subsol apare mereu în engleză: „Designed and built by Luca Gradisteanu. Send email”

## [0.13.0] — 2026-10-31

### Adăugat
- Limba interfeței: administrarea se afișează în limba implicită aleasă în Setări, imediat după salvare (de ex. engleză → tot panoul în engleză). Conținutul scris de utilizator (pagini, subsol, nume site, texte slide) nu se traduce și nu se schimbă
- Folderul `lang/` cu fișiere de limbă numite după codul oficial (`ro.php`, `en.php`, `pl.php`, `fr.php`, `pt-br.php` …): cheia este textul în engleză, valoarea traducerea. Incluse: română și engleză
- Limbă proprie: copiezi `lang/en.php` în `lang/<cod>.php`, schimbi `_name` și traduci valorile (vezi `lang/README.md`); apare singură în listă. Textele netraduse apar în engleză
- Textele publice ale temei (404, galerie, fișiere, slider, meniu) urmează limba paginii; temele pot folosi `t('Text')`

### Modificat
- Toate textele din administrare, editor, previzualizarea Aspectului și mesajele de eroare trec prin `t()`
- Semnătura din subsol rămâne neschimbată în toate limbile

## [0.12.0] — 2026-10-31

### Adăugat
- Teme: pagina „Teme” din administrare listează temele din `themes/`, le activează, le șterge (nu cea implicită sau cea activă), le duplică (punct de plecare pentru o temă proprie) și instalează teme din arhive .zip
- O temă = un folder cu `layout.php`, `page.php`, `home.php`, `404.php`, `style.css` (+ `theme.json` opțional). Fișierele opționale lipsă se iau din tema implicită
- `THEMES.md`: ghid pentru cine face teme (variabile, funcții, reguli)
- Instalarea din .zip respinge căile periculoase și ignoră fișierele de alt tip (ascunse, executabile); fișierele PHP din `themes/` nu se pot deschide direct din browser

### Schimbat
- Site-ul folosește tema activă (cu revenire automată la „implicită” dacă tema aleasă lipsește). Culorile din „Aspect” se aplică peste tema activă

## [0.11.0] — 2026-10-31

### Adăugat
- Număr nelimitat de limbi: Setări → Limbi permite adăugarea oricărei limbi (cod de 2–3 litere, ex. `pl`, `pt-br`, plus nume) sau alegerea uneia cunoscute
- Ștergerea unei limbi o scoate doar din site; paginile, subsolul și setările ei rămân salvate. Dacă adaugi din nou limba (același cod), conținutul de dinainte este disponibil imediat
- Dacă ștergi limba implicită, se alege automat alta; ultima limbă nu poate fi ștearsă

### Schimbat
- Limba implicită se alege doar dintre limbile active

## [0.10.1] — 2026-10-31

### Reparat
- Conținutul paginii avea lățime maximă 820 px, deci părea deplasat spre stânga față de subsol și antet. Acum conținutul paginii, antetul și subsolul au aceleași margini stânga și dreapta (coloana de 1060 px); pentru text mai îngust folosește un container „Îngust” sau „Mediu”

## [0.10.0] — 2026-10-31

### Adăugat
- Buton „Iframe” în editor: lipești codul `<iframe …>` (hartă Google, YouTube sau orice alt conținut încorporat) sau doar adresa și se inserează în pagină, în card, în secțiune, în container sau în subsol. Se acceptă adrese http/https; opțiuni de înălțime și „lățime completă”
- „Proprietăți bloc” funcționează și pe iframe (înălțime, lățime completă)

## [0.9.0] — 2026-10-31

### Adăugat
- Subsolul are conținut editabil, pe limbă (Setări → „Conținutul subsolului”), cu același editor ca paginile: text, imagini, carduri, secțiuni, containere, slidere. Apare între hartă și credit
- Vechiul text simplu din subsol este preluat automat în editor

### Schimbat
- Editorul vizual a fost mutat într-un fișier comun (`admin/views/_editor.php`), folosit de pagini și de subsol
- Diacriticele se salvează ca atare în HTML (nu ca entități)

## [0.8.0] — 2026-10-31

### Adăugat
- Harta din subsol se poate seta lipind codul „Încorporează o hartă” din Google Maps (`<iframe …>`); se păstrează doar adresa (acceptate doar adrese Google Maps prin https) și înălțimea din cod. Are prioritate față de coordonate

## [0.7.0] — 2026-10-31

### Adăugat
- Hartă Google Maps în subsol (Setări → „Hartă în subsol”): bifă de activare, latitudine, longitudine (se pot lipi împreună, ca din Google Maps), zoom și înălțimea hărții
- Coordonatele se validează; cu valori invalide harta nu se activează

### Schimbat
- Subsolul își ajustează înălțimea după conținut (hartă + text + credit)

## [0.6.0] — 2026-10-31

### Schimbat
- Noul nume: **LiteBase CMS** (numerotarea versiunilor continuă neschimbată). Cookie-ul de sesiune se numește acum `litebase`, deci te autentifici o dată după actualizare
- Sliderele sunt obiecte separate: fiecare are propria pagină în administrare, de unde îi încarci imaginile; imaginile aparțin doar acelui slider
- Un slider se poate pune în orice pagină: câmpul „Slider” (la începutul paginii) și/sau butonul „Slider” din editor (cod `[slider id=N]` în text). Pe o pagină pot fi mai multe slidere
- Sliderele vechi (lista de imagini a paginii de start) se migrează automat într-un slider asociat paginii de start

### Adăugat
- Setări → „URL Rewriting”: activat implicit (adrese `/ro/contact`); dezactivat folosește `/index.php/ro/contact`, pentru servere fără `mod_rewrite`

## [0.5.0] — 2026-10-31

### Adăugat
- Imaginile încărcate la o pagină pot fi așezate la stânga, la dreapta (textul curge în jurul lor), centrat sau în galerie; imaginile din editor au aceleași opțiuni (clase în dialogul de imagine)
- SEO: câmp „Cuvinte cheie” pe fiecare pagină și cuvinte cheie implicite pe limbă în Setări (`<meta name="keywords">`)
- Programare: „Vizibilă de la” / „până la” pe fiecare pagină; gol = vizibilă imediat, fără limită. Pagina programată sau expirată dispare din meniu, sitemap și dă 404 (administratorul o poate previzualiza)
- Carduri în editor (1–4 pe rând, cu bifă pentru umbră/shadow), secțiuni (benzi pe toată lățimea, fundal deschis/accent/închis) și containere (lățime limitată); buton „Proprietăți bloc” pentru a schimba ulterior umbra etc.
- Aspect: culori pentru carduri și secțiuni

### Schimbat
- Baza de date se migrează automat la prima rulare (coloane noi: meta_keywords, visible_from, visible_until, files.align)

## [0.4.0] — 2026-10-31

### Adăugat
- Pagina „Aspect” în administrare: culorile se aleg separat pentru fiecare element (pagină, antet, meniu, linkuri din conținut, accordion, slider, subsol)
- Linkuri (în meniu, în conținut și în subsol): culoare inactiv, la hover și la click, plus alegerea subliniării (fără / mereu / doar la hover)
- Previzualizare live, în care meniul, linkurile și accordionul reacționează real la hover și la click
- Teme gata făcute (Implicit, Verde, Portocaliu, Monocrom, Întunecat), cu posibilitatea de a ajusta apoi orice culoare; buton de resetare pentru fiecare câmp
- Culorile se aplică pe site prin variabile CSS; se salvează doar ce diferă de valorile implicite, iar valorile sunt validate strict (doar coduri #rrggbb)

### Schimbat
- `themes/default/style.css` conține doar structura; culorile vin din variabilele emise în `<head>`

## [0.3.1] — 2026-10-31

### Reparat
- Editor: butoanele din bara de unelte (link, imagine, tabel, accordion) erau ascunse în meniul „⋮” pe ecrane obișnuite; acum toate butoanele sunt vizibile, pe mai multe rânduri
- Editor: zona de scris are acum o înălțime minimă de 380 px

## [0.3.0] — 2026-10-31

### Adăugat
- Accordion: buton „Accordion” în editorul de pagini; inserează un grup de elemente care se deschid la click (HTML nativ `details`/`summary`, accesibil de la tastatură)
- Pe site, într-un accordion se ține deschis un singur element odată; elementele pornesc închise
- Stil pentru accordion în temă

## [0.2.0] — 2026-10-31

### Adăugat
- Slidere: încărcare a mai multor imagini deodată; fiecare devine un slide, ordonabil cu ↑↓
- Slider pe site: săgeți înainte/înapoi și glisare cu degetul pe telefon (pe lângă schimbarea automată)
- Versionare semver: fișierul `VERSION`, acest istoric, versiunea afișată în administrare
- Mesaj clar când fișierele trimise depășesc limita serverului (`post_max_size`), în loc de eroare generică

## [0.1.0] — 2026-10-31

Prima versiune.

### Adăugat
- Pagini cu subpagini, ordonare, ascundere, meniu, editor vizual
- Imagini și fișiere atașate paginilor, cu micșorare automată a imaginilor
- Slidere pe pagina de start (câte o imagine pe rând)
- SEO: URL-uri prietenoase, meta per pagină, sitemap.xml, robots.txt, canonical, Open Graph
- Mai multe limbi (RO, EN, DE, FR, ES, IT, HU)
- Administrare cu autentificare, CSRF, setări și schimbare parolă
- Temă responsive
