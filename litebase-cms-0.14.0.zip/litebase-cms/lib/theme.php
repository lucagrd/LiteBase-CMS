<?php
declare(strict_types=1);

/*
 * Tema de culori. Fiecare element al site-ului are propriile culori, păstrate în baza de date
 * (setarea "theme", doar valorile diferite de cele implicite) și transmise paginii ca variabile CSS.
 */

const THEME_DECO = ['none', 'always', 'hover'];

function theme_schema(): array
{
    $c = fn(string $k, string $label, string $d) => ['key' => $k, 'label' => $label, 'type' => 'color', 'default' => $d, 'var' => '--' . str_replace('_', '-', $k)];
    $u = fn(string $k, string $label, string $d, string $var) => ['key' => $k, 'label' => $label, 'type' => 'underline', 'default' => $d, 'var' => $var];

    return [
        ['title' => t('Page'), 'fields' => [
            $c('page_bg', t('Page background'), '#ffffff'),
            $c('text', t('Text'), '#1f2933'),
            $c('text_muted', t('Secondary text (descriptions, tagline)'), '#667585'),
            $c('heading', t('Headings'), '#1f2933'),
            $c('line', t('Lines and borders (tables, gallery)'), '#e3e8ee'),
        ]],
        ['title' => t('Header'), 'fields' => [
            $c('header_bg', t('Header background'), '#ffffff'),
            $c('header_line', t('Line under the header'), '#e3e8ee'),
            $c('brand', t('Site name'), '#1f2933'),
            $c('tagline', t('Tagline'), '#667585'),
        ]],
        ['title' => t('Menu'), 'fields' => [
            $c('menu_link', t('Link (inactive)'), '#1f2933'),
            $c('menu_link_hover', t('Link on hover'), '#0b5cad'),
            $c('menu_link_click', t('Link on click'), '#063a6e'),
            $c('menu_current', t('Current page'), '#0b5cad'),
            $c('menu_hover_bg', t('Background on hover / current page'), '#f5f8fb'),
            $u('menu_underline', t('Link underline'), 'none', '--menu-deco'),
            $c('submenu_bg', t('Submenu background'), '#ffffff'),
            $c('submenu_line', t('Submenu border'), '#e3e8ee'),
        ]],
        ['title' => t('Links in the content'), 'fields' => [
            $c('link', t('Link (inactive)'), '#0b5cad'),
            $c('link_hover', t('Link on hover'), '#094a8a'),
            $c('link_click', t('Link on click'), '#063a6e'),
            $u('link_underline', t('Link underline'), 'always', '--link-deco'),
        ]],
        ['title' => t('Accordion'), 'fields' => [
            $c('acc_bg', t('Item background'), '#ffffff'),
            $c('acc_line', t('Border'), '#e3e8ee'),
            $c('acc_title', t('Title'), '#1f2933'),
            $c('acc_hover_bg', t('Title background on hover'), '#f5f8fb'),
            $c('acc_icon', t('The + / – sign'), '#0b5cad'),
        ]],
        ['title' => t('Cards'), 'fields' => [
            $c('card_bg', t('Card background'), '#ffffff'),
            $c('card_line', t('Card border'), '#e3e8ee'),
            $c('card_shadow', t('Shadow color (when the card has a shadow)'), '#1f2933'),
        ]],
        ['title' => t('Buttons'), 'fields' => [
            $c('btn_bg', t('Button background'), '#0b5cad'),
            $c('btn_text', t('Button text'), '#ffffff'),
            $c('btn_border', t('Button border'), '#0b5cad'),
            $c('btn_hover_bg', t('Background on hover'), '#094a8a'),
            $c('btn_hover_text', t('Text on hover'), '#ffffff'),
            $c('btn_hover_border', t('Border on hover'), '#094a8a'),
            ['key' => 'btn_radius', 'label' => t('Corner radius (px) of rounded buttons'), 'type' => 'px', 'default' => '8', 'var' => '--btn-radius', 'min' => 0, 'max' => 40],
            ['key' => 'btn_border_w', 'label' => t('Border thickness (px)'), 'type' => 'px', 'default' => '2', 'var' => '--btn-border-w', 'min' => 0, 'max' => 8],
        ]],
        ['title' => t('Sections'), 'fields' => [
            $c('sec_light_bg', t('“Light” section – background'), '#f5f8fb'),
            $c('sec_accent_bg', t('“Accent” section – background'), '#0b5cad'),
            $c('sec_accent_text', t('“Accent” section – text'), '#ffffff'),
            $c('sec_dark_bg', t('“Dark” section – background'), '#1f2933'),
            $c('sec_dark_text', t('“Dark” section – text'), '#ffffff'),
        ]],
        ['title' => t('Slider'), 'fields' => [
            $c('slider_text', t('Text on the image'), '#ffffff'),
            $c('slider_arrow_bg', t('Arrows background'), '#000000'),
            $c('slider_arrow_fg', t('Arrows and dots'), '#ffffff'),
        ]],
        ['title' => t('Footer'), 'fields' => [
            $c('footer_bg', t('Footer background'), '#f5f8fb'),
            $c('footer_line', t('Line above'), '#e3e8ee'),
            $c('footer_text', t('Text'), '#667585'),
            $c('footer_link', t('Link (inactive)'), '#0b5cad'),
            $c('footer_link_hover', t('Link on hover'), '#094a8a'),
            $c('footer_link_click', t('Link on click'), '#063a6e'),
            $u('footer_underline', t('Link underline'), 'always', '--footer-deco'),
        ]],
    ];
}

function theme_fields(): array
{
    $out = [];
    foreach (theme_schema() as $g) {
        foreach ($g['fields'] as $f) {
            $out[$f['key']] = $f;
        }
    }
    return $out;
}

function theme_defaults(): array
{
    $out = [];
    foreach (theme_fields() as $k => $f) {
        $out[$k] = $f['default'];
    }
    return $out;
}

function theme_valid(array $field, $v): bool
{
    if (!is_string($v)) {
        return false;
    }
    if ($field['type'] === 'color') {
        return preg_match('/^#[0-9a-f]{6}$/i', $v) === 1;
    }
    if ($field['type'] === 'px') {
        return preg_match('/^\d{1,2}$/', $v) === 1 && (int)$v >= $field['min'] && (int)$v <= $field['max'];
    }
    return in_array($v, THEME_DECO, true);
}

/** Valorile salvate (doar cele diferite de implicit), validate. */
function theme_saved(): array
{
    $raw = json_decode((string)setting('theme', '{}'), true);
    $out = [];
    if (is_array($raw)) {
        foreach (theme_fields() as $k => $f) {
            if (isset($raw[$k]) && theme_valid($f, $raw[$k])) {
                $out[$k] = strtolower($raw[$k]);
            }
        }
    }
    return $out;
}

/** Valorile efective: implicitele peste care se aplică cele salvate. */
function theme_values(): array
{
    return theme_saved() + theme_defaults();
}

function theme_deco(string $mode): array
{
    if ($mode === 'always') {
        return ['underline', 'underline'];
    }
    if ($mode === 'hover') {
        return ['none', 'underline'];
    }
    return ['none', 'none'];
}

function theme_css(): string
{
    $values = theme_values();
    $decl = [];
    foreach (theme_fields() as $k => $f) {
        $v = $values[$k];
        if ($f['type'] === 'underline') {
            [$normal, $hover] = theme_deco($v);
            $decl[] = $f['var'] . ':' . $normal;
            $decl[] = $f['var'] . '-hover:' . $hover;
        } elseif ($f['type'] === 'px') {
            $decl[] = $f['var'] . ':' . (int)$v . 'px';
        } else {
            $decl[] = $f['var'] . ':' . $v;
        }
    }
    return ':root{' . implode(';', $decl) . '}';
}

/** Valorile din formular → doar cele valide și diferite de implicit. */
function theme_from_post(array $post): array
{
    $over = [];
    $def = theme_defaults();
    foreach (theme_fields() as $k => $f) {
        $v = $post[$k] ?? null;
        if (theme_valid($f, $v)) {
            $v = strtolower($v);
            if ($v !== $def[$k]) {
                $over[$k] = $v;
            }
        }
    }
    return $over;
}

/** Variantă de culori pornind de la o culoare principală. */
function theme_accent_preset(string $accent, string $hover, string $click, string $soft, string $line): array
{
    return [
        'menu_link_hover' => $accent, 'menu_current' => $accent, 'menu_link_click' => $click, 'menu_hover_bg' => $soft,
        'link' => $accent, 'link_hover' => $hover, 'link_click' => $click,
        'acc_icon' => $accent, 'acc_hover_bg' => $soft,
        'btn_bg' => $accent, 'btn_border' => $accent, 'btn_hover_bg' => $hover, 'btn_hover_border' => $hover,
        'card_line' => $line, 'sec_light_bg' => $soft, 'sec_accent_bg' => $accent,
        'footer_bg' => $soft, 'footer_link' => $accent, 'footer_link_hover' => $hover, 'footer_link_click' => $click,
        'line' => $line, 'header_line' => $line, 'submenu_line' => $line, 'acc_line' => $line, 'footer_line' => $line,
    ];
}

function theme_presets(): array
{
    return [
        ['id' => 'implicit', 'label' => t('Default (blue)'), 'values' => []],
        ['id' => 'verde', 'label' => t('Green'), 'values' => theme_accent_preset('#1b7f4b', '#136338', '#0b4426', '#eef7f1', '#dcebe1')],
        ['id' => 'portocaliu', 'label' => t('Orange'), 'values' => theme_accent_preset('#d9480f', '#b03a0a', '#7c2806', '#fff4ec', '#f0e1d6')],
        ['id' => 'monocrom', 'label' => t('Monochrome'), 'values' => theme_accent_preset('#111111', '#555555', '#000000', '#f2f2f2', '#e5e5e5')],
        ['id' => 'intunecat', 'label' => t('Dark'), 'values' => [
            'page_bg' => '#12161c', 'text' => '#e3e8ee', 'text_muted' => '#9aa7b5', 'heading' => '#ffffff', 'line' => '#2a323c',
            'header_bg' => '#171c23', 'header_line' => '#2a323c', 'brand' => '#ffffff', 'tagline' => '#9aa7b5',
            'menu_link' => '#d5dde6', 'menu_link_hover' => '#7db7f2', 'menu_link_click' => '#a9d0f7', 'menu_current' => '#7db7f2',
            'menu_hover_bg' => '#222a34', 'submenu_bg' => '#171c23', 'submenu_line' => '#2a323c',
            'link' => '#7db7f2', 'link_hover' => '#a9d0f7', 'link_click' => '#cfe5fb',
            'acc_bg' => '#171c23', 'acc_line' => '#2a323c', 'acc_title' => '#e3e8ee', 'acc_hover_bg' => '#222a34', 'acc_icon' => '#7db7f2',
            'card_bg' => '#171c23', 'card_line' => '#2a323c', 'card_shadow' => '#000000',
            'sec_light_bg' => '#171c23', 'sec_accent_bg' => '#1d4f86', 'sec_dark_bg' => '#0b0e12',
            'footer_bg' => '#171c23', 'footer_line' => '#2a323c', 'footer_text' => '#9aa7b5',
            'footer_link' => '#7db7f2', 'footer_link_hover' => '#a9d0f7', 'footer_link_click' => '#cfe5fb',
        ]],
    ];
}

/** Pagina de probă din previzualizare: aceeași structură și aceleași clase ca site-ul real. */
function theme_preview_html(): string
{
    $css = e(theme_url('style.css'));
    $vars = theme_css();
    $t = 't';
    $lang = e(i18n_lang());
    $para = t('This is an ordinary text with a %s and another %s. Hover over them or click them to see the colors.', '<a href="#">' . t('link in the content') . '</a>', '<a href="#">' . t('link') . '</a>');
    return <<<HTML
<!doctype html>
<html lang="{$lang}"><head><meta charset="utf-8">
<link rel="stylesheet" href="{$css}">
<style>{$vars}</style>
<style>body{min-height:0}.slider{aspect-ratio:auto;height:190px}.arrow{opacity:1!important}.page{flex:none;padding-top:20px;padding-bottom:24px}.page h1{margin-bottom:10px}.content h2{margin:.7em 0 .5em}.content .accordion{margin-top:.6em;margin-bottom:0}.section{padding:20px 0!important}</style>
</head><body>
<header class="site-header"><div class="wrap bar">
  <a class="brand" href="#"><span class="brand-name">{$t('Site name')}</span><span class="brand-tag">{$t('Site tagline')}</span></a>
  <nav class="nav"><ul>
    <li class="cur"><a href="#">{$t('Home')}</a></li>
    <li class="has-sub"><a href="#">{$t('Services')}</a><ul class="sub"><li><a href="#">Web design</a></li><li><a href="#">{$t('Maintenance')}</a></li></ul></li>
    <li><a href="#">Contact</a></li>
    <li class="langs"><a class="cur" href="#">RO</a><a href="#">EN</a></li>
  </ul></nav>
</div></header>
<section class="slider">
  <div class="slide on"><div style="width:100%;height:100%;background:linear-gradient(135deg,#6a9bc3,#2c4a66)"></div>
    <div class="cap"><strong>{$t('A slide title')}</strong><span>{$t('Text on the image')}</span></div></div>
  <button type="button" class="arrow prev">‹</button><button type="button" class="arrow next">›</button>
  <div class="dots"><button type="button" class="on"></button><button type="button"></button><button type="button"></button></div>
</section>
<main class="page">
  <div class="wrap"><h1>{$t('Page title')}</h1></div>
  <div class="content">
    <p>{$para}</p>
    <h2>{$t('A subheading')}</h2>
    <div class="accordion">
      <details open><summary>{$t('First accordion item')}</summary><p>{$t('The text that opens on click.')}</p></details>
      <details><summary>{$t('Second item')}</summary><p>{$t('Other text.')}</p></details>
    </div>
    <div class="cards cols-2">
      <div class="card card-shadow"><h3>{$t('Card with shadow')}</h3><p>{$t('Text in the card.')}</p></div>
      <div class="card"><h3>{$t('Card without shadow')}</h3><p>{$t('Text in the card.')}</p></div>
    </div>
    <p><a class="cms-btn" href="#">{$t('Rounded button')}</a> <a class="cms-btn cms-btn-square" href="#">{$t('Square button')}</a></p>
    <section class="section bg-light"><h3>{$t('Light section')}</h3><p>{$t('Text in the section.')}</p></section>
    <section class="section bg-accent"><h3>{$t('Accent section')}</h3><p>{$t('Text in the section.')}</p></section>
    <section class="section bg-dark"><h3>{$t('Dark section')}</h3><p>{$t('Text in the section.')}</p></section>
  </div>
</main>
<footer class="site-footer"><div class="wrap">
  <div>{$t('© 2026 My Company')}</div>
  <div class="credit">Designed and built by Luca Gradisteanu. <a href="#">Send email</a></div>
</div></footer>
<script>document.addEventListener('click',function(e){if(e.target.closest('a'))e.preventDefault()});</script>
</body></html>
HTML;
}
