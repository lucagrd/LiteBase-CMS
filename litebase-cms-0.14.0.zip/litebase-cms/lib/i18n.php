<?php
declare(strict_types=1);

/*
 * Limbi de interfață. Fișierele sunt în folderul lang/, numite după codul limbii (ro.php, en.php, pl.php, fr.php, pt-br.php ...).
 * Cheia este textul în engleză; valoarea este traducerea. Un text care lipsește dintr-un fișier apare în engleză.
 * O limbă nouă se face copiind lang/en.php în lang/<cod>.php și traducând valorile (vezi lang/README.md).
 */

function lang_dir(): string
{
    return ROOT . '/lang';
}

/** Codurile limbilor care au fișier în lang/ => numele lor (din cheia '_name' a fișierului). */
function lang_files(): array
{
    $out = [];
    foreach (glob(lang_dir() . '/*.php') ?: [] as $f) {
        $code = basename($f, '.php');
        if (valid_lang_code($code)) {
            $d = lang_load($code);
            $out[$code] = (string)($d['_name'] ?? $code);
        }
    }
    ksort($out);
    return $out;
}

function lang_load(string $code): array
{
    static $cache = [];
    if (!isset($cache[$code])) {
        $f = lang_dir() . '/' . $code . '.php';
        $d = valid_lang_code($code) && is_file($f) ? require $f : [];
        $cache[$code] = is_array($d) ? $d : [];
    }
    return $cache[$code];
}

/** Limba folosită acum pentru texte: 'pt-br' → încearcă pt-br, apoi pt, apoi engleza. */
function i18n_lang(?string $set = null): string
{
    static $cur = null;
    if ($set !== null) {
        $cur = $set;
    }
    return $cur ?? 'en';
}

function i18n_dict(): array
{
    static $memo = [];
    $l = i18n_lang();
    if (!isset($memo[$l])) {
        $d = lang_load($l);
        if (!$d && str_contains($l, '-')) {
            $d = lang_load(explode('-', $l)[0]);
        }
        $memo[$l] = $d;
    }
    return $memo[$l];
}

/** Traduce un text (cheia = textul în engleză). Argumentele se inserează cu sprintf: t('%d files', 3). */
function t(string $s, ...$args): string
{
    $d = i18n_dict();
    $r = isset($d[$s]) && is_string($d[$s]) && $d[$s] !== '' ? $d[$s] : $s;
    return $args ? vsprintf($r, $args) : $r;
}
