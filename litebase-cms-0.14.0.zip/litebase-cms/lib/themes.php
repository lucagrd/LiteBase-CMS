<?php
declare(strict_types=1);

/*
 * Teme: fiecare temă este un folder în themes/ cu cel puțin layout.php, page.php, home.php, 404.php și style.css.
 * Fișierele lipsă (ex. _slider.php, _content.php) se iau din tema „default”.
 * Detalii pentru cei care fac teme: THEMES.md
 */

const THEME_REQUIRED = ['layout.php', 'page.php', 'home.php', '404.php', 'style.css'];
const THEME_ALLOWED_EXT = ['php', 'css', 'js', 'json', 'md', 'txt', 'html', 'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'woff', 'woff2', 'ttf', 'otf', 'eot'];

function themes_dir(): string
{
    return ROOT . '/themes';
}

function theme_slug_valid(string $s): bool
{
    return (bool)preg_match('~^[a-z0-9][a-z0-9_-]{0,39}$~', $s);
}

function theme_is_installed(string $slug): bool
{
    if (!theme_slug_valid($slug)) {
        return false;
    }
    foreach (THEME_REQUIRED as $f) {
        if (!is_file(themes_dir() . '/' . $slug . '/' . $f)) {
            return false;
        }
    }
    return true;
}

/** Tema activă (dacă cea aleasă lipsește sau e stricată, se folosește „default”). */
function active_theme(): string
{
    static $a = null;
    if ($a === null) {
        $s = (string)setting('active_theme', 'default');
        $a = theme_is_installed($s) ? $s : 'default';
    }
    return $a;
}

/** Calea unui fișier din tema activă, sau din „default” dacă tema activă nu îl are. */
function theme_path(string $file): string
{
    $p = themes_dir() . '/' . active_theme() . '/' . $file;
    return is_file($p) ? $p : themes_dir() . '/default/' . $file;
}

/** Adresa publică a unui fișier al temei active (ex. style.css), cu versiune ca să nu rămână în cache. */
function theme_url(string $file): string
{
    $slug = is_file(themes_dir() . '/' . active_theme() . '/' . $file) ? active_theme() : 'default';
    $p = themes_dir() . '/' . $slug . '/' . $file;
    return url('themes/' . $slug . '/' . $file) . (is_file($p) ? '?v=' . filemtime($p) : '');
}

function theme_info(string $slug): array
{
    $info = ['slug' => $slug, 'name' => $slug, 'version' => '', 'author' => '', 'description' => ''];
    $j = @file_get_contents(themes_dir() . '/' . $slug . '/theme.json');
    $d = $j ? json_decode($j, true) : null;
    if (is_array($d)) {
        foreach (['name', 'version', 'author', 'description'] as $k) {
            if (isset($d[$k]) && is_string($d[$k])) {
                $info[$k] = mb_substr($d[$k], 0, 300);
            }
        }
    }
    if ($info['name'] === '') {
        $info['name'] = $slug;
    }
    return $info;
}

/** Temele instalate, cu informațiile din theme.json. */
function themes_list(): array
{
    $out = [];
    foreach (scandir(themes_dir()) ?: [] as $d) {
        if ($d[0] !== '.' && is_dir(themes_dir() . '/' . $d) && theme_is_installed($d)) {
            $out[] = theme_info($d);
        }
    }
    return $out;
}

function rrmdir(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    foreach (scandir($dir) ?: [] as $f) {
        if ($f === '.' || $f === '..') {
            continue;
        }
        $p = $dir . '/' . $f;
        is_dir($p) && !is_link($p) ? rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

function rcopy(string $from, string $to): void
{
    @mkdir($to, 0755, true);
    foreach (scandir($from) ?: [] as $f) {
        if ($f === '.' || $f === '..') {
            continue;
        }
        is_dir("$from/$f") ? rcopy("$from/$f", "$to/$f") : copy("$from/$f", "$to/$f");
    }
}

function theme_slug_free(string $base): string
{
    $slug = $base = trim(substr(preg_replace('~[^a-z0-9_-]+~', '-', strtolower(slugify($base))), 0, 36), '-') ?: 'tema';
    for ($i = 2; is_dir(themes_dir() . '/' . $slug); $i++) {
        $slug = $base . '-' . $i;
    }
    return $slug;
}

function theme_write_json(string $slug, array $data): void
{
    file_put_contents(themes_dir() . '/' . $slug . '/theme.json', json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

/** Copiază o temă existentă într-una nouă, ca punct de plecare. Returnează [slug, eroare]. */
function theme_duplicate(string $from, string $name): array
{
    $name = trim($name);
    if ($name === '') {
        return [null, t('Give the new theme a name.')];
    }
    if (!theme_is_installed($from)) {
        return [null, t('The source theme does not exist.')];
    }
    $slug = theme_slug_free($name);
    rcopy(themes_dir() . '/' . $from, themes_dir() . '/' . $slug);
    $info = theme_info($from);
    theme_write_json($slug, [
        'name' => mb_substr($name, 0, 60), 'version' => '1.0.0',
        'author' => '', 'description' => t('Based on the theme “%s”.', $info['name']),
    ]);
    return [$slug, null];
}

/** Instalează o temă dintr-o arhivă .zip. Returnează [slug, eroare]. */
function theme_install_zip(string $file): array
{
    if (!class_exists('ZipArchive')) {
        return [null, t('The server does not have the PHP “zip” extension. Upload the theme folder directly to themes/ over FTP.')];
    }
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) {
        return [null, t('The archive cannot be read.')];
    }
    if ($zip->numFiles > 400) {
        $zip->close();
        return [null, t('The archive has too many files.')];
    }
    // Rădăcina temei: fie la nivelul arhivei, fie într-un singur folder
    $names = [];
    $total = 0;
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $st = $zip->statIndex($i);
        $n = str_replace('\\', '/', (string)$st['name']);
        if ($n === '' || str_contains($n, '..') || $n[0] === '/' || preg_match('~^[a-zA-Z]:~', $n)) {
            $zip->close();
            return [null, t('The archive contains forbidden paths.')];
        }
        $total += (int)$st['size'];
        $names[$i] = $n;
    }
    if ($total > 20 * 1024 * 1024) {
        $zip->close();
        return [null, t('The theme is too large (maximum 20 MB unpacked).')];
    }
    $prefix = '';
    if (!in_array('layout.php', $names, true)) {
        foreach ($names as $n) {
            if (preg_match('~^([^/]+)/layout\.php$~', $n, $m)) {
                $prefix = $m[1] . '/';
                break;
            }
        }
    }
    foreach (THEME_REQUIRED as $req) {
        if (!in_array($prefix . $req, $names, true)) {
            $zip->close();
            return [null, t('The theme is incomplete: the file “%s” is missing.', $req)];
        }
    }
    $meta = [];
    $j = $zip->getFromName($prefix . 'theme.json');
    if ($j !== false && is_array($d = json_decode($j, true))) {
        $meta = $d;
    }
    $baseName = is_string($meta['name'] ?? null) && $meta['name'] !== '' ? $meta['name'] : ($prefix !== '' ? rtrim($prefix, '/') : 'tema');
    $slug = theme_slug_free($baseName);
    $dest = themes_dir() . '/' . $slug;
    foreach ($names as $i => $n) {
        if ($prefix !== '' && !str_starts_with($n, $prefix)) {
            continue;
        }
        $rel = substr($n, strlen($prefix));
        if ($rel === '' || str_ends_with($rel, '/')) {
            continue;
        }
        $ext = strtolower(pathinfo($rel, PATHINFO_EXTENSION));
        if (!in_array($ext, THEME_ALLOWED_EXT, true) || preg_match('~(^|/)\.~', $rel)) {
            continue;   // fișiere de alt tip (ascunse, executabile etc.) se ignoră
        }
        $target = $dest . '/' . $rel;
        @mkdir(dirname($target), 0755, true);
        file_put_contents($target, (string)$zip->getFromIndex($i));
    }
    $zip->close();
    if (!theme_is_installed($slug)) {
        rrmdir($dest);
        return [null, t('The theme could not be installed.')];
    }
    return [$slug, null];
}
