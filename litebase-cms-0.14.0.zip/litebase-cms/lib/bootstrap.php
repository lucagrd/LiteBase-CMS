<?php
declare(strict_types=1);

define('ROOT', dirname(__DIR__));
define('DATA_DIR', ROOT . '/data');
define('UPLOAD_DIR', ROOT . '/uploads');

date_default_timezone_set('Europe/Bucharest');
mb_internal_encoding('UTF-8');

require __DIR__ . '/i18n.php';
require __DIR__ . '/theme.php';
require __DIR__ . '/themes.php';

// Versiunea (semver MAJOR.MINOR.PATCH) se ține în fișierul VERSION
define('CMS_VERSION', is_file(ROOT . '/VERSION') ? trim((string)file_get_contents(ROOT . '/VERSION')) : '0.0.0');

const IMG_EXT  =['jpg', 'jpeg', 'png', 'gif', 'webp'];
const FILE_EXT = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'txt', 'csv', 'zip'];

/* ------------------------------------------------------------------ */
/* Config, URL-uri, escapare                                           */
/* ------------------------------------------------------------------ */

function cfg(string $k, $default = null)
{
    static $c = null;
    if ($c === null) {
        $c = require ROOT . '/config.php';
    }
    return $c[$k] ?? $default;
}

function base_url(): string
{
    static $b = null;
    if ($b !== null) {
        return $b;
    }
    $doc  = rtrim(str_replace('\\', '/', (string)(realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '')), '/');
    $root = str_replace('\\', '/', ROOT);
    $b = ($doc !== '' && str_starts_with($root, $doc)) ? substr($root, strlen($doc)) : '';
    return $b;
}

function url(string $path = ''): string
{
    return base_url() . '/' . ltrim($path, '/');
}

/** Este activat URL Rewriting? (implicit da) */
function rewrite_on(): bool
{
    return setting('url_rewrite', '1') !== '0';
}

/** Adresă de pagină: /ro/contact cu URL Rewriting, /index.php/ro/contact fără. */
function route(string $path = ''): string
{
    return base_url() . (rewrite_on() ? '' : '/index.php') . '/' . ltrim($path, '/');
}

function site_origin(): string
{
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    return ($https ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
}

function abs_url(string $u): string
{
    return site_origin() . $u;
}

function e($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

/* ------------------------------------------------------------------ */
/* Baza de date (SQLite)                                               */
/* ------------------------------------------------------------------ */

function db(): PDO
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    if (!is_dir(DATA_DIR)) {
        mkdir(DATA_DIR, 0775, true);
    }
    foreach ([DATA_DIR, ROOT . '/lib'] as $dir) {
        if (is_dir($dir) && !is_file($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        }
    }
    $pdo = new PDO('sqlite:' . DATA_DIR . '/cms.sqlite');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');

    $pdo->exec('CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL
    )');
    $pdo->exec('CREATE TABLE IF NOT EXISTS settings (
        k TEXT PRIMARY KEY,
        v TEXT
    )');
    $pdo->exec('CREATE TABLE IF NOT EXISTS pages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        parent_id INTEGER NULL REFERENCES pages(id) ON DELETE CASCADE,
        lang TEXT NOT NULL,
        title TEXT NOT NULL,
        slug TEXT NOT NULL DEFAULT "",
        content TEXT NOT NULL DEFAULT "",
        position INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1,
        in_menu INTEGER NOT NULL DEFAULT 1,
        is_home INTEGER NOT NULL DEFAULT 0,
        meta_title TEXT NOT NULL DEFAULT "",
        meta_description TEXT NOT NULL DEFAULT "",
        updated_at TEXT NOT NULL DEFAULT ""
    )');
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_pages_lang_parent ON pages(lang, parent_id, slug)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
        filename TEXT NOT NULL,
        original TEXT NOT NULL,
        is_image INTEGER NOT NULL DEFAULT 0,
        caption TEXT NOT NULL DEFAULT "",
        position INTEGER NOT NULL DEFAULT 0
    )');
    $pdo->exec('CREATE TABLE IF NOT EXISTS sliders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        active INTEGER NOT NULL DEFAULT 1
    )');
    $pdo->exec('CREATE TABLE IF NOT EXISTS slides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        lang TEXT NOT NULL,
        image TEXT NOT NULL,
        title TEXT NOT NULL DEFAULT "",
        text TEXT NOT NULL DEFAULT "",
        link TEXT NOT NULL DEFAULT "",
        position INTEGER NOT NULL DEFAULT 0,
        active INTEGER NOT NULL DEFAULT 1
    )');

    // Migrări: coloane adăugate în versiuni ulterioare (instalările vechi se actualizează singure)
    if ((int)$pdo->query('PRAGMA user_version')->fetchColumn() < 1) {
        ensure_column($pdo, 'pages', 'meta_keywords', "TEXT NOT NULL DEFAULT ''");
        ensure_column($pdo, 'pages', 'visible_from', "TEXT NOT NULL DEFAULT ''");
        ensure_column($pdo, 'pages', 'visible_until', "TEXT NOT NULL DEFAULT ''");
        ensure_column($pdo, 'files', 'align', "TEXT NOT NULL DEFAULT 'gallery'");
        $pdo->exec('PRAGMA user_version = 1');
    }
    if ((int)$pdo->query('PRAGMA user_version')->fetchColumn() < 2) {
        // 0.6.0: slidere ca obiecte separate; fiecare imagine aparține unui singur slider
        ensure_column($pdo, 'slides', 'slider_id', 'INTEGER NOT NULL DEFAULT 0');
        ensure_column($pdo, 'pages', 'slider_id', 'INTEGER NOT NULL DEFAULT 0');
        // Imaginile vechi (câte o listă pe limbă, afișate pe pagina de start) devin câte un slider
        $langsOld = $pdo->query('SELECT DISTINCT lang FROM slides WHERE slider_id = 0')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($langsOld as $l) {
            $pdo->prepare('INSERT INTO sliders(name, active) VALUES(?, 1)')->execute(['Slider pagina de start (' . $l . ')']);
            $sid = (int)$pdo->lastInsertId();
            $pdo->prepare('UPDATE slides SET slider_id = ? WHERE lang = ? AND slider_id = 0')->execute([$sid, $l]);
            $pdo->prepare('UPDATE pages SET slider_id = ? WHERE lang = ? AND is_home = 1')->execute([$sid, $l]);
        }
        $pdo->exec('PRAGMA user_version = 2');
    }
    return $pdo;
}

function ensure_column(PDO $pdo, string $table, string $column, string $ddl): void
{
    $cols = array_column($pdo->query('PRAGMA table_info(' . $table . ')')->fetchAll(), 'name');
    if (!in_array($column, $cols, true)) {
        $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $column . ' ' . $ddl);
    }
}

function setting(string $k, ?string $default = null): ?string
{
    if (!isset($GLOBALS['_settings'])) {
        $GLOBALS['_settings'] = [];
        foreach (db()->query('SELECT k, v FROM settings') as $r) {
            $GLOBALS['_settings'][$r['k']] = $r['v'];
        }
    }
    return $GLOBALS['_settings'][$k] ?? $default;
}

function set_setting(string $k, string $v): void
{
    db()->prepare('INSERT INTO settings(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v')
        ->execute([$k, $v]);
    unset($GLOBALS['_settings']);
}

/* ------------------------------------------------------------------ */
/* Limbi                                                               */
/* ------------------------------------------------------------------ */

/** Limbile predefinite. */
function preset_langs(): array
{
    return [
        'ro' => 'Română', 'en' => 'English', 'de' => 'Deutsch', 'fr' => 'Français',
        'es' => 'Español', 'it' => 'Italiano', 'hu' => 'Magyar',
    ];
}

/** Limbile adăugate de utilizator (cod => nume). Rămân înregistrate și după ce sunt scoase din site. */
function custom_langs(): array
{
    $j = json_decode((string)setting('lang_custom', '{}'), true);
    $out = [];
    foreach (is_array($j) ? $j : [] as $c => $n) {
        if (valid_lang_code((string)$c) && is_string($n) && $n !== '') {
            $out[(string)$c] = $n;
        }
    }
    return $out;
}

/** Toate limbile cunoscute (predefinite + adăugate), active sau nu. */
function known_langs(): array
{
    return preset_langs() + custom_langs();
}

function valid_lang_code(string $c): bool
{
    return (bool)preg_match('~^[a-z]{2,3}(-[a-z0-9]{2,8})?$~', $c)
        && !in_array($c, ['lib', 'api', 'www', 'cdn'], true);
}

function langs(): array
{
    $known = known_langs();
    $out = [];
    foreach (explode(',', (string)setting('languages', 'ro,en')) as $c) {
        $c = trim($c);
        if (isset($known[$c])) {
            $out[$c] = $known[$c];
        }
    }
    return $out ?: ['ro' => 'Română'];
}

function default_lang(): string
{
    $l = langs();
    $d = (string)setting('default_lang', 'ro');
    return isset($l[$d]) ? $d : (string)array_key_first($l);
}

function site_name(string $lang): string
{
    return (string)setting('site_name_' . $lang, 'Site-ul meu');
}

function ensure_home_pages(): void
{
    $titles = ['ro' => 'Acasă', 'en' => 'Home', 'de' => 'Startseite', 'fr' => 'Accueil', 'es' => 'Inicio', 'it' => 'Home', 'hu' => 'Kezdőlap'];
    foreach (langs() as $code => $label) {
        $st = db()->prepare('SELECT id FROM pages WHERE lang = ? AND is_home = 1');
        $st->execute([$code]);
        if (!$st->fetch()) {
            db()->prepare('INSERT INTO pages(parent_id, lang, title, slug, content, position, active, in_menu, is_home, updated_at)
                           VALUES(NULL, ?, ?, "", ?, 0, 1, 1, 1, ?)')
                ->execute([$code, $titles[$code] ?? 'Home', '<p>Bine ai venit! Editează această pagină din panoul de administrare.</p>', date('Y-m-d H:i:s')]);
        }
    }
}

/* ------------------------------------------------------------------ */
/* Sesiune, autentificare, CSRF                                        */
/* ------------------------------------------------------------------ */

function session_boot(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('litebase');
        session_set_cookie_params([
            'path'     => base_url() . '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function logged_in(): bool
{
    return !empty($_SESSION['uid']);
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void
{
    // Dacă fișierele trimise depășesc post_max_size, PHP golește tot $_POST
    if (!$_POST && (int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        http_response_code(413);
        exit(t('The uploaded files are too large for the server (post_max_size = %s). Upload fewer images at a time or raise the limit in php.ini.', ini_get('post_max_size')));
    }
    $sent = (string)($_POST['csrf'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        http_response_code(400);
        exit(t('Invalid request (CSRF token). Reload the page and try again.'));
    }
}

function flash(?string $msg = null, string $type = 'ok')
{
    if ($msg !== null) {
        $_SESSION['flash'] = ['msg' => $msg, 'type' => $type];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ------------------------------------------------------------------ */
/* Pagini                                                              */
/* ------------------------------------------------------------------ */

function slugify(string $s): string
{
    $s = strtr($s, [
        'ă' => 'a', 'â' => 'a', 'î' => 'i', 'ș' => 's', 'ş' => 's', 'ț' => 't', 'ţ' => 't',
        'Ă' => 'a', 'Â' => 'a', 'Î' => 'i', 'Ș' => 's', 'Ş' => 's', 'Ț' => 't', 'Ţ' => 't',
    ]);
    if (function_exists('iconv')) {
        $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
        if ($t !== false) {
            $s = $t;
        }
    }
    $s = strtolower($s);
    $s = (string)preg_replace('~[^a-z0-9]+~', '-', $s);
    $s = trim($s, '-');
    return $s !== '' ? $s : 'pagina';
}

function page_by_id(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM pages WHERE id = ?');
    $st->execute([$id]);
    $r = $st->fetch();
    return $r ?: null;
}

/**
 * Starea unei pagini: 'hidden' (dezactivată), 'scheduled' (încă nu a început),
 * 'expired' (a trecut data de sfârșit) sau 'live'. Fără date completate = vizibilă imediat, fără limită.
 */
function page_state(array $p, ?string $now = null): string
{
    if (!(int)$p['active']) {
        return 'hidden';
    }
    $now = $now ?? date('Y-m-d H:i:s');
    $from = (string)($p['visible_from'] ?? '');
    $until = (string)($p['visible_until'] ?? '');
    if ($from !== '' && $now < $from) {
        return 'scheduled';
    }
    if ($until !== '' && $now >= $until) {
        return 'expired';
    }
    return 'live';
}

function page_is_live(array $p): bool
{
    return page_state($p) === 'live';
}

/** „2026-11-20T09:30” (câmp datetime-local) → „2026-11-20 09:30:00”; orice altceva → '' */
function parse_local_datetime(string $v): string
{
    if (preg_match('/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})$/', trim($v), $m)) {
        $d = DateTime::createFromFormat('Y-m-d H:i', $m[1] . ' ' . $m[2]);
        if ($d && $d->format('Y-m-d H:i') === $m[1] . ' ' . $m[2]) {
            return $m[1] . ' ' . $m[2] . ':00';
        }
    }
    return '';
}

function datetime_for_input(string $v): string
{
    return $v === '' ? '' : str_replace(' ', 'T', substr($v, 0, 16));
}

/** Cuvinte cheie: separate prin virgulă, fără duplicate, maxim 15. */
function normalize_keywords(string $s): string
{
    $out = [];
    $seen = [];
    foreach (preg_split('/[,;\n]+/u', $s) as $k) {
        $k = mb_substr(trim((string)preg_replace('/\s+/u', ' ', $k)), 0, 60);
        $key = mb_strtolower($k);
        if ($k !== '' && !isset($seen[$key])) {
            $seen[$key] = true;
            $out[] = $k;
        }
    }
    return implode(', ', array_slice($out, 0, 15));
}

function pages_index(string $lang, bool $fresh = false): array
{
    static $cache = [];
    if ($fresh || !isset($cache[$lang])) {
        $st = db()->prepare('SELECT * FROM pages WHERE lang = ? ORDER BY position, id');
        $st->execute([$lang]);
        $rows = [];
        foreach ($st as $r) {
            $rows[(int)$r['id']] = $r;
        }
        $cache[$lang] = $rows;
    }
    return $cache[$lang];
}

function parent_of(array $p): ?int
{
    return $p['parent_id'] === null ? null : (int)$p['parent_id'];
}

function children_of(array $idx, ?int $parent): array
{
    $out = [];
    foreach ($idx as $p) {
        if (!(int)$p['is_home'] && parent_of($p) === $parent) {
            $out[] = $p;
        }
    }
    return $out;
}

/** Lista plată, în ordinea arborelui, cu cheia 'depth'. */
function page_tree(string $lang, bool $onlyActive = false): array
{
    $idx = pages_index($lang);
    $out = [];
    $walk = function (?int $parent, int $depth) use (&$walk, &$out, $idx, $onlyActive) {
        foreach (children_of($idx, $parent) as $p) {
            if ($onlyActive && !page_is_live($p)) {
                continue;
            }
            $p['depth'] = $depth;
            $out[] = $p;
            $walk((int)$p['id'], $depth + 1);
        }
    };
    $walk(null, 0);
    return $out;
}

function descendant_ids(array $idx, int $id): array
{
    $out = [];
    $stack = [$id];
    while ($stack) {
        $cur = array_pop($stack);
        foreach ($idx as $p) {
            if (parent_of($p) === $cur) {
                $out[] = (int)$p['id'];
                $stack[] = (int)$p['id'];
            }
        }
    }
    return $out;
}

/** Harta Google din subsol: ['lat'=>..,'lng'=>..,'zoom'=>..,'height'=>..] sau null dacă e oprită/incompletă. */
function footer_map(): ?array
{
    if (setting('map_on', '0') !== '1') {
        return null;
    }
    $lat = setting('map_lat', '');
    $lng = setting('map_lng', '');
    $embed = (string)setting('map_embed', '');
    if ($embed !== '' && map_embed_valid($embed)) {
        $src = $embed;                       // linkul de încorporare lipit din Google Maps
    } elseif (is_numeric($lat) && is_numeric($lng)) {
        $src = 'https://maps.google.com/maps?q=' . (float)$lat . ',' . (float)$lng . '&z=' . max(1, min(20, (int)setting('map_zoom', '15'))) . '&output=embed';
    } else {
        return null;
    }
    return [
        'src' => $src,
        'zoom' => max(1, min(20, (int)setting('map_zoom', '15'))),
        'height' => max(150, min(800, (int)setting('map_height', '300'))),
    ];
}

/** Acceptă doar adrese de încorporare Google Maps, prin https. */
function map_embed_valid(string $u): bool
{
    $p = parse_url($u);
    return $p && ($p['scheme'] ?? '') === 'https'
        && in_array(strtolower($p['host'] ?? ''), ['www.google.com', 'google.com', 'maps.google.com', 'www.google.ro', 'google.ro'], true)
        && str_starts_with($p['path'] ?? '', '/maps');
}

/** Din codul <iframe …> lipit (sau dintr-un link simplu) scoate adresa și, dacă există, înălțimea. */
function parse_map_embed(string $raw): array
{
    $raw = trim($raw);
    $height = null;
    if (preg_match('~<iframe[^>]*>~i', $raw, $m)) {
        $tag = $m[0];
        if (!preg_match('~\ssrc\s*=\s*(["\'])(.*?)\1~is', $tag, $s)) {
            return ['', null];
        }
        $raw = $s[2];
        if (preg_match('~\sheight\s*=\s*["\']?(\d+)~i', $tag, $h)) {
            $height = (int)$h[1];
        }
    }
    $raw = html_entity_decode($raw, ENT_QUOTES, 'UTF-8');
    return [map_embed_valid($raw) ? $raw : '', $height];
}

/** Număr zecimal din text (acceptă virgulă); null dacă nu e valid sau e în afara intervalului. */
function parse_coord(string $v, float $min, float $max): ?float
{
    $v = str_replace(',', '.', trim($v));
    if ($v === '' || !is_numeric($v)) {
        return null;
    }
    $f = (float)$v;
    return ($f >= $min && $f <= $max) ? $f : null;
}

function slider_by_id(int $id): ?array
{
    if ($id <= 0) {
        return null;
    }
    $st = db()->prepare('SELECT * FROM sliders WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

function page_url(array $p): string
{
    if ((int)$p['is_home']) {
        return route($p['lang'] . '/');
    }
    $idx = pages_index($p['lang']);
    $segs = [$p['slug']];
    $cur = $p;
    $guard = 0;
    while (parent_of($cur) !== null && isset($idx[parent_of($cur)]) && $guard++ < 20) {
        $cur = $idx[parent_of($cur)];
        array_unshift($segs, $cur['slug']);
    }
    return route($p['lang'] . '/' . implode('/', array_map('rawurlencode', $segs)));
}

function resolve_page(string $lang, array $segs, bool $includeInactive = false): ?array
{
    $parent = null;
    $page = null;
    foreach ($segs as $s) {
        $st = db()->prepare('SELECT * FROM pages WHERE lang = ? AND slug = ? COLLATE NOCASE AND is_home = 0 AND parent_id IS ?');
        $st->execute([$lang, $s, $parent]);
        $page = $st->fetch();
        if (!$page || (!$includeInactive && !page_is_live($page))) {
            return null;
        }
        $parent = (int)$page['id'];
    }
    return $page ?: null;
}

function home_page(string $lang): ?array
{
    $st = db()->prepare('SELECT * FROM pages WHERE lang = ? AND is_home = 1');
    $st->execute([$lang]);
    return $st->fetch() ?: null;
}

function page_files(int $pageId): array
{
    $st = db()->prepare('SELECT * FROM files WHERE page_id = ? ORDER BY position, id');
    $st->execute([$pageId]);
    return $st->fetchAll();
}

/* ------------------------------------------------------------------ */
/* Încărcări de fișiere                                                */
/* ------------------------------------------------------------------ */

/**
 * Salvează un fișier încărcat în /uploads. Aruncă RuntimeException cu mesaj pentru utilizator.
 * Returnează ['filename', 'original', 'is_image'].
 */
function save_upload(array $f, bool $imageOnly = false, string $subdir = ''): array
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(t('The upload failed (code %d).', (int)($f['error'] ?? -1)));
    }
    $max = (int)cfg('max_upload_mb', 10) * 1024 * 1024;
    if ($f['size'] > $max) {
        throw new RuntimeException(t('The file “%s” exceeds %d MB.', $f['name'], cfg('max_upload_mb', 10)));
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    $isImage = in_array($ext, IMG_EXT, true);
    if (!$isImage && ($imageOnly || !in_array($ext, FILE_EXT, true))) {
        throw new RuntimeException(t('File type not allowed: “%s”.', $f['name']));
    }
    if ($isImage && @getimagesize($f['tmp_name']) === false) {
        throw new RuntimeException(t('“%s” is not a valid image.', $f['name']));
    }
    $dir = UPLOAD_DIR . ($subdir !== '' ? '/' . $subdir : '');
    if (!is_dir($dir)) {
        mkdir($dir, 0775, true);
    }
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . '/' . $name)) {
        throw new RuntimeException(t('Could not save the file to disk (permissions on the uploads folder?).'));
    }
    if ($isImage) {
        resize_image($dir . '/' . $name, $ext);
    }
    return [
        'filename' => ($subdir !== '' ? $subdir . '/' : '') . $name,
        'original' => mb_substr(basename($f['name']), 0, 150),
        'is_image' => $isImage ? 1 : 0,
    ];
}

function resize_image(string $path, string $ext, int $max = 1600): void
{
    if (!function_exists('imagecreatetruecolor') || $ext === 'gif') {
        return;
    }
    $info = @getimagesize($path);
    if (!$info) {
        return;
    }
    [$w, $h] = $info;
    if (max($w, $h) <= $max) {
        return;
    }
    $r  = $max / max($w, $h);
    $nw = (int)round($w * $r);
    $nh = (int)round($h * $r);
    $src = null;
    if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) {
        $src = @imagecreatefromjpeg($path);
    } elseif ($ext === 'png' && function_exists('imagecreatefrompng')) {
        $src = @imagecreatefrompng($path);
    } elseif ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
        $src = @imagecreatefromwebp($path);
    }
    if (!$src) {
        return;
    }
    $dst = imagecreatetruecolor($nw, $nh);
    if ($ext === 'png' || $ext === 'webp') {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        imagefill($dst, 0, 0, imagecolorallocatealpha($dst, 0, 0, 0, 127));
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    if ($ext === 'jpg' || $ext === 'jpeg') {
        imagejpeg($dst, $path, 85);
    } elseif ($ext === 'png') {
        imagepng($dst, $path, 6);
    } else {
        imagewebp($dst, $path, 85);
    }
    imagedestroy($src);
    imagedestroy($dst);
}

function delete_upload(string $filename): void
{
    $p = UPLOAD_DIR . '/' . $filename;
    if ($filename !== '' && is_file($p) && str_starts_with(realpath($p) ?: '', realpath(UPLOAD_DIR) ?: "\0")) {
        @unlink($p);
    }
}

/** Normalizează $_FILES['x'] cu name[] într-o listă de fișiere individuale. */
function files_list(string $field): array
{
    $out = [];
    if (empty($_FILES[$field]['name'])) {
        return $out;
    }
    $f = $_FILES[$field];
    if (!is_array($f['name'])) {
        return $f['error'] === UPLOAD_ERR_NO_FILE ? [] : [$f];
    }
    foreach ($f['name'] as $i => $n) {
        if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        $out[] = ['name' => $n, 'type' => $f['type'][$i], 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
    }
    return $out;
}
