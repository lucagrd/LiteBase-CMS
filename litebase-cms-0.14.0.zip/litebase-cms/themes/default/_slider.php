<?php /* Un slider. Variabile: $slides, $uid, $extraClass */ ?>
<section class="slider<?= $extraClass !== '' ? ' ' . e($extraClass) : '' ?>" id="<?= e($uid) ?>" data-slider aria-label="<?= e(t('Slideshow')) ?>">
  <?php foreach ($slides as $i => $s): ?>
    <?php $tag = $s['link'] !== '' ? 'a' : 'div'; ?>
    <<?= $tag ?> class="slide<?= $i === 0 ? ' on' : '' ?>" <?= $s['link'] !== '' ? 'href="' . e($s['link']) . '"' : '' ?>>
      <img src="<?= e(url('uploads/' . $s['image'])) ?>" alt="<?= e($s['title']) ?>" <?= $i > 0 ? 'loading="lazy"' : '' ?>>
      <?php if ($s['title'] !== '' || $s['text'] !== ''): ?>
      <div class="cap">
        <?php if ($s['title'] !== ''): ?><strong><?= e($s['title']) ?></strong><?php endif; ?>
        <?php if ($s['text'] !== ''): ?><span><?= e($s['text']) ?></span><?php endif; ?>
      </div>
      <?php endif; ?>
    </<?= $tag ?>>
  <?php endforeach; ?>
  <?php if (count($slides) > 1): ?>
  <button type="button" class="arrow prev" aria-label="<?= e(t('Previous image')) ?>">‹</button>
  <button type="button" class="arrow next" aria-label="<?= e(t('Next image')) ?>">›</button>
  <div class="dots">
    <?php foreach ($slides as $i => $s): ?><button type="button" class="<?= $i === 0 ? 'on' : '' ?>" aria-label="<?= e(t('Slide %d', $i + 1)) ?>"></button><?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>
