<main class="wrap page" style="text-align:center;padding:60px 0">
  <h1>404</h1>
  <p><?= e(t('The page you are looking for was not found.')) ?></p>
  <p><a href="<?= e(route($lang . '/')) ?>"><?= e(t('← Back to the start page')) ?></a></p>
</main>
