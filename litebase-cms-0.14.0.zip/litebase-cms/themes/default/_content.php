<?php /* Conținutul paginii: imagini aliniate + text (blocuri full-width permise), apoi galerie și fișiere */ ?>
<div class="content">
  <?php foreach ($aligned as $img): ?>
    <figure class="att att-<?= e($img['align']) ?>">
      <a href="<?= e(url('uploads/' . $img['filename'])) ?>" target="_blank" rel="noopener"><img src="<?= e(url('uploads/' . $img['filename'])) ?>" alt="<?= e($img['caption'] !== '' ? $img['caption'] : $page['title']) ?>"></a>
      <?php if ($img['caption'] !== ''): ?><figcaption><?= e($img['caption']) ?></figcaption><?php endif; ?>
    </figure>
  <?php endforeach; ?>
  <?= $page['content'] ?>
</div>
<div class="after wrap">

  <?php if ($images): ?>
  <section class="gallery" aria-label="<?= e(t('Gallery')) ?>">
    <?php foreach ($images as $img): ?>
      <figure>
        <a href="<?= e(url('uploads/' . $img['filename'])) ?>" target="_blank" rel="noopener">
          <img src="<?= e(url('uploads/' . $img['filename'])) ?>" alt="<?= e($img['caption'] !== '' ? $img['caption'] : $page['title']) ?>" loading="lazy">
        </a>
        <?php if ($img['caption'] !== ''): ?><figcaption><?= e($img['caption']) ?></figcaption><?php endif; ?>
      </figure>
    <?php endforeach; ?>
  </section>
  <?php endif; ?>

  <?php if ($docs): ?>
  <section class="downloads">
    <h2><?= e(t('Files')) ?></h2>
    <ul>
      <?php foreach ($docs as $d): ?>
        <li><a href="<?= e(url('uploads/' . $d['filename'])) ?>" download="<?= e($d['original']) ?>"><?= e($d['caption'] !== '' ? $d['caption'] : $d['original']) ?></a></li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>
</div>
