<!doctype html>
<html lang="<?= e($lang) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($metaTitle) ?></title>
<?php if ($metaDesc !== ''): ?><meta name="description" content="<?= e($metaDesc) ?>"><?php endif; ?>
<?php if (!empty($metaKeywords)): ?><meta name="keywords" content="<?= e($metaKeywords) ?>"><?php endif; ?>
<?php if (!empty($noindex)): ?><meta name="robots" content="noindex,nofollow"><?php endif; ?>
<?php if ($canonical !== ''): ?><link rel="canonical" href="<?= e($canonical) ?>"><?php endif; ?>
<meta property="og:type" content="website">
<meta property="og:title" content="<?= e($metaTitle) ?>">
<?php if ($metaDesc !== ''): ?><meta property="og:description" content="<?= e($metaDesc) ?>"><?php endif; ?>
<?php if ($ogImage !== ''): ?><meta property="og:image" content="<?= e($ogImage) ?>"><?php endif; ?>
<style><?= theme_css() ?></style>
<link rel="stylesheet" href="<?= e(theme_url('style.css')) ?>">
</head>
<body>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="<?= e(route($lang . '/')) ?>">
      <span class="brand-name"><?= e($siteName) ?></span>
      <?php if ($tagline !== ''): ?><span class="brand-tag"><?= e($tagline) ?></span><?php endif; ?>
    </a>

    <input type="checkbox" id="nav-toggle" class="nav-toggle" aria-label="<?= e(t('Menu')) ?>">
    <label for="nav-toggle" class="burger" aria-hidden="true"><span></span><span></span><span></span></label>

    <nav class="nav" aria-label="<?= e(t('Main menu')) ?>">
      <ul>
        <?php foreach ($menu as $m): ?>
          <li class="<?= $m['children'] ? 'has-sub ' : '' ?><?= ((int)$m['id'] === $currentId) ? 'cur' : '' ?>">
            <a href="<?= e(page_url($m)) ?>"><?= e($m['title']) ?></a>
            <?php if ($m['children']): ?>
              <ul class="sub">
                <?php foreach ($m['children'] as $c): ?>
                  <li><a href="<?= e(page_url($c)) ?>"><?= e($c['title']) ?></a></li>
                <?php endforeach; ?>
              </ul>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
        <?php if (count($allLangs) > 1): ?>
          <li class="langs">
            <?php foreach ($allLangs as $code => $label): ?>
              <a class="<?= $code === $lang ? 'cur' : '' ?>" href="<?= e(route($code . '/')) ?>" hreflang="<?= e($code) ?>" title="<?= e($label) ?>"><?= e(strtoupper($code)) ?></a>
            <?php endforeach; ?>
          </li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</header>

<?php if (!empty($isAdmin) && $page && !page_is_live($page)): ?>
  <div class="preview-note"><?= e(t('Preview: this page is not visible to visitors right now (%s).', ['hidden' => t('it is disabled'), 'scheduled' => t('it is scheduled to appear later'), 'expired' => t('it has expired')][page_state($page)] ?? t('it is not active'))) ?></div>
<?php endif; ?>

<?= $content ?>

<footer class="site-footer">
  <?php if ($map = footer_map()): ?>
  <div class="wrap">
    <div class="footer-map">
      <iframe title="<?= e(t('Map')) ?>" src="<?= e($map['src']) ?>" style="height:<?= (int)$map['height'] ?>px" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
    </div>
  </div>
  <?php endif; ?>
  <?php if ($footer !== ''): ?><div class="content footer-content"><?= $footer ?></div><?php endif; ?>
  <div class="wrap">
    <?php if (cfg('credit')): ?>
      <div class="credit">Designed and built by <?= e(cfg('credit_name')) ?>. <a href="mailto:<?= e(cfg('credit_email')) ?>">Send email</a></div>
    <?php endif; ?>
  </div>
</footer>
<?php if (str_contains($content . $footer, 'data-slider')) { require theme_path('_slider_js.php'); } ?>
<?php if (!empty($page) && str_contains((string)$page['content'], 'class="accordion"')): ?>
<script>
// Într-un accordion se ține deschis un singur element odată
document.querySelectorAll('.accordion').forEach(function (g) {
  g.addEventListener('toggle', function (e) {
    if (!e.target.open) return;
    g.querySelectorAll(':scope > details[open]').forEach(function (d) { if (d !== e.target) d.open = false; });
  }, true);
});
</script>
<?php endif; ?>
</body>
</html>
