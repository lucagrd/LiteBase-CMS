<?= $topSlider ?>
<main class="page">
  <div class="wrap"><h1><?= e($page['title']) ?></h1></div>
  <?php require theme_path('_content.php'); ?>
</main>
