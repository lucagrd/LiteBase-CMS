<?= $topSlider ?>
<main class="page home">
  <?php require theme_path('_content.php'); ?>
</main>
