<script>
document.querySelectorAll('[data-slider]').forEach(function (box) {
  var slides = box.querySelectorAll('.slide');
  if (slides.length < 2) return;
  var dots = box.querySelectorAll('.dots button');
  var cur = 0, timer;
  function show(n) {
    slides[cur].classList.remove('on'); dots[cur].classList.remove('on');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('on'); dots[cur].classList.add('on');
  }
  function start() { clearInterval(timer); timer = setInterval(function () { show(cur + 1); }, 5000); }
  function go(n) { show(n); start(); }
  dots.forEach(function (d, i) { d.addEventListener('click', function () { go(i); }); });
  box.querySelector('.prev').addEventListener('click', function () { go(cur - 1); });
  box.querySelector('.next').addEventListener('click', function () { go(cur + 1); });
  var x0 = null;
  box.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, {passive: true});
  box.addEventListener('touchend', function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0; x0 = null;
    if (Math.abs(dx) > 40) go(cur + (dx < 0 ? 1 : -1));
  });
  box.addEventListener('mouseenter', function () { clearInterval(timer); });
  box.addEventListener('mouseleave', start);
  start();
});
</script>
