<div class="card">
  <h2><?= e(t('First setup')) ?></h2>
  <p class="muted"><?= e(t('Create the administrator account. The password must have at least 8 characters.')) ?></p>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" action="<?= e(aurl(['a' => 'setup'])) ?>">
    <?= csrf_field() ?>
    <div class="field"><label for="n"><?= e(t('Site name')) ?></label><input type="text" id="n" name="site_name" placeholder="<?= e(t('My website')) ?>"></div>
    <div class="field"><label for="u"><?= e(t('Username')) ?></label><input type="text" id="u" name="username" value="admin" autocomplete="username"></div>
    <div class="field"><label for="p"><?= e(t('Password')) ?></label><input type="password" id="p" name="password" autocomplete="new-password"></div>
    <button class="btn" type="submit"><?= e(t('Create account')) ?></button>
  </form>
</div>
