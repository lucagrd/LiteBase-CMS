<?php $isHome = (int)$page['is_home']; $isNew = !(int)$page['id']; ?>
<div class="top">
  <h1><?= $isNew ? t('New page') : t('Edit page') ?> <span class="badge"><?= e(langs()[$lang] ?? $lang) ?></span></h1>
  <a href="<?= e(aurl(['a' => 'pages', 'lang' => $lang])) ?>"><?= e(t('← Back to pages')) ?></a>
</div>

<form method="post" enctype="multipart/form-data" action="<?= e(aurl(['a' => 'page_save'])) ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$page['id'] ?>">
  <input type="hidden" name="lang" value="<?= e($lang) ?>">

  <div class="cols">
    <div>
      <div class="card">
        <div class="field">
          <label for="title"><?= e(t('Title')) ?></label>
          <input type="text" id="title" name="title" value="<?= e($page['title']) ?>" required>
        </div>
        <div class="field" style="margin-bottom:0">
          <label for="content"><?= e(t('Content')) ?></label>
          <textarea id="content" name="content" rows="18"><?= e($page['content']) ?></textarea>
        </div>
      </div>

      <div class="card">
        <h2><?= e(t('Attached images and files')) ?></h2>
        <?php if ($files): ?>
        <ul class="files">
          <?php foreach ($files as $f): ?>
          <li>
            <?php if ((int)$f['is_image']): ?>
              <img src="<?= e(url('uploads/' . $f['filename'])) ?>" alt="">
            <?php else: ?>
              <span class="badge"><?= e(t('file')) ?></span>
            <?php endif; ?>
            <div class="nm">
              <span><?= e($f['original']) ?></span>
              <input type="text" name="caption[<?= (int)$f['id'] ?>]" value="<?= e($f['caption']) ?>" placeholder="<?= e(t('Description (optional)')) ?>">
              <?php if ((int)$f['is_image']): ?>
              <select name="align[<?= (int)$f['id'] ?>]" aria-label="<?= e(t('Image alignment')) ?>">
                <?php foreach (['gallery' => t('In the gallery (at the end of the page)'), 'left' => t('Left (text wraps around it)'), 'right' => t('Right (text wraps around it)'), 'center' => t('Centered (above the text)')] as $val => $lbl): ?>
                  <option value="<?= $val ?>" <?= ($f['align'] ?? 'gallery') === $val ? 'selected' : '' ?>><?= e($lbl) ?></option>
                <?php endforeach; ?>
              </select>
              <?php endif; ?>
            </div>
            <button class="btn danger sm" type="submit" name="file_id" value="<?= (int)$f['id'] ?>"
                    formaction="<?= e(aurl(['a' => 'file_delete'])) ?>" formnovalidate
                    onclick="return confirm(<?= e(json_encode(t('Delete the file?'))) ?>)"><?= e(t('Delete')) ?></button>
          </li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <div class="field" style="margin-bottom:0">
          <label for="files"><?= e(t('Add files')) ?></label>
          <input type="file" id="files" name="files[]" multiple>
          <div class="help"><?= e(t('Images (jpg, png, gif, webp) appear in the page gallery; other files (pdf, doc, xls, zip …) appear as download links.')) ?> <?= e(t('Maximum %d MB per file.', (int)cfg('max_upload_mb', 10))) ?></div>
        </div>
      </div>
    </div>

    <div>
      <div class="card">
        <h2><?= e(t('Publishing')) ?></h2>
        <label class="check"><input type="checkbox" name="active" value="1" <?= (int)$page['active'] ? 'checked' : '' ?>> <?= e(t('Page is active (visible on the site)')) ?></label>
        <label class="check"><input type="checkbox" name="in_menu" value="1" <?= (int)$page['in_menu'] ? 'checked' : '' ?>> <?= e(t('Show in the menu')) ?></label>
        <?php if (!$isHome): ?>
        <div class="field" style="margin-top:10px">
          <label for="visible_from"><?= e(t('Visible from')) ?></label>
          <input type="datetime-local" id="visible_from" name="visible_from" value="<?= e(datetime_for_input((string)$page['visible_from'])) ?>">
        </div>
        <div class="field">
          <label for="visible_until"><?= e(t('Visible until')) ?></label>
          <input type="datetime-local" id="visible_until" name="visible_until" value="<?= e(datetime_for_input((string)$page['visible_until'])) ?>">
          <div class="help"><?= e(t('Leave both fields empty to make the page visible immediately, with no time limit. The time is the server time (Bucharest).')) ?></div>
        </div>
        <?php endif; ?>
        <button class="btn" type="submit" style="width:100%;margin-top:6px"><?= e(t('Save')) ?></button>
        <?php if (!$isNew && (int)$page['active']): ?>
          <div class="help" style="margin-top:8px"><a href="<?= e(page_url($page)) ?>" target="_blank" rel="noopener"><?= e(t('View page ↗')) ?></a></div>
        <?php endif; ?>
      </div>

      <?php if (!$isHome): ?>
      <div class="card">
        <h2><?= e(t('Position in the site')) ?></h2>
        <div class="field">
          <label for="parent_id"><?= e(t('Parent page')) ?></label>
          <select id="parent_id" name="parent_id">
            <option value="0"><?= e(t('— top level —')) ?></option>
            <?php foreach ($parents as $p): ?>
              <option value="<?= (int)$p['id'] ?>" <?= parent_of($page) === (int)$p['id'] ? 'selected' : '' ?>><?= e(str_repeat('— ', $p['depth']) . $p['title']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="field" style="margin-bottom:0">
          <label for="slug"><?= e(t('URL address')) ?></label>
          <input type="text" id="slug" name="slug" value="<?= e($page['slug']) ?>" placeholder="<?= e(t('generated from the title')) ?>">
        </div>
      </div>
      <?php endif; ?>

      <div class="card">
        <h2><?= e(t('Slider')) ?></h2>
        <div class="field" style="margin-bottom:0">
          <label for="slider_id"><?= e(t('Slider shown at the top of the page')) ?></label>
          <select id="slider_id" name="slider_id">
            <option value="0"><?= e(t('— none —')) ?></option>
            <?php foreach ($sliders as $sl): ?>
              <option value="<?= (int)$sl['id'] ?>" <?= (int)$page['slider_id'] === (int)$sl['id'] ? 'selected' : '' ?>><?= e($sl['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="help"><?= e(t('Sliders are created in the “Sliders” section. You can also put a slider in the middle of the text with the “Slider” button in the editor.')) ?></div>
        </div>
      </div>

      <div class="card">
        <h2><?= e(t('SEO (Google)')) ?></h2>
        <div class="field">
          <label for="meta_title"><?= e(t('Title for Google')) ?></label>
          <input type="text" id="meta_title" name="meta_title" value="<?= e($page['meta_title']) ?>" maxlength="70" placeholder="<?= e(t('default: the page title')) ?>">
          <div class="help"><?= e(t('Recommended: under 60 characters.')) ?></div>
        </div>
        <div class="field">
          <label for="meta_description"><?= e(t('Description')) ?></label>
          <textarea id="meta_description" name="meta_description" rows="3" maxlength="200"><?= e($page['meta_description']) ?></textarea>
          <div class="help"><?= e(t('Recommended: 120–160 characters.')) ?></div>
        </div>
        <div class="field" style="margin-bottom:0">
          <label for="meta_keywords"><?= e(t('Keywords')) ?></label>
          <input type="text" id="meta_keywords" name="meta_keywords" value="<?= e($page['meta_keywords']) ?>" placeholder="<?= e(t('e.g. construction, renovation, estimates')) ?>">
          <div class="help"><?= e(t('Separated by commas. If left empty, the ones from Settings are used.')) ?></div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php $editorSelector = '#content'; require __DIR__ . '/_editor.php'; ?>
