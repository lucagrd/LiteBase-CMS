<?php $js = fn(string $s) => json_encode(t($s), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); /* Editorul vizual (TinyMCE) cu blocuri: carduri, secțiuni, containere, slidere. Variabile: $editorSelector, $sliders */ ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/6.8.3/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
  selector: <?= json_encode($editorSelector) ?>,
  min_height: 380,
  menubar: false,
  entity_encoding: 'raw',
  branding: false,
  promotion: false,
  plugins: 'lists link image table code autoresize',
  toolbar_mode: 'wrap', // toate butoanele vizibile, pe mai multe rânduri (nu ascunse în „⋮”)
  toolbar: 'undo redo | blocks | bold italic underline | bullist numlist | link image table | alignleft aligncenter alignright | accordion cmsslider cmsembed cmscard cmssection cmscontainer cmsbutton cmsprops | removeformat code',
  image_class_list: [
    {title: <?= $js('No alignment') ?>, value: ''},
    {title: <?= $js('Left (text wraps around it)') ?>, value: 'img-left'},
    {title: <?= $js('Right (text wraps around it)') ?>, value: 'img-right'},
    {title: <?= $js('Centered') ?>, value: 'img-center'}
  ],
  content_style: [
    'details{border:1px solid #dde3ea;border-radius:8px;padding:.5em 1em;margin:.5em 0}summary{font-weight:600;cursor:pointer}',
    'img.img-left{float:left;margin:4px 20px 12px 0}img.img-right{float:right;margin:4px 0 12px 20px}img.img-center{display:block;margin:12px auto}',
    '.cards{display:grid;gap:14px;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin:.8em 0}',
    '.cards.cols-1{grid-template-columns:1fr}.cards.cols-2{grid-template-columns:repeat(2,1fr)}.cards.cols-3{grid-template-columns:repeat(3,1fr)}.cards.cols-4{grid-template-columns:repeat(4,1fr)}',
    '.card{border:1px solid #dde3ea;border-radius:10px;padding:10px 16px;background:#fff}.card.card-shadow{box-shadow:0 6px 20px rgba(20,40,60,.16)}',
    '.card>:first-child{margin-top:0}.card>:last-child{margin-bottom:0}',
    '.section{padding:20px 24px;margin:.8em 0;border-radius:6px;outline:1px dashed #8fa8c2}.section.bg-light{background:#f5f8fb}.section.bg-accent{background:#0b5cad;color:#fff}.section.bg-dark{background:#1f2933;color:#fff}.section.bg-accent h1,.section.bg-accent h2,.section.bg-accent h3,.section.bg-dark h1,.section.bg-dark h2,.section.bg-dark h3{color:inherit}.section.text-center{text-align:center}',
    '.container{outline:1px dashed #b7c4d1;padding:10px 14px;margin:.8em 0}',
    'a.cms-btn{display:inline-block;padding:.6em 1.3em;background:#0b5cad;color:#fff!important;border:2px solid #0b5cad;border-radius:8px;font-weight:600;text-decoration:none!important}a.cms-btn.cms-btn-square{border-radius:0}',
    '.embed{margin:.8em 0}.embed iframe{max-width:100%;border:0;background:#f1f4f7}.embed.embed-full iframe{width:100%}'
  ].join('\n'),
  setup: function (editor) {
    var item = function (n) {
      return '<details><summary>' + <?= $js('Item title') ?> + ' ' + n + '</summary><p>' + <?= $js('The text that opens on click.') ?> + '</p></details>';
    };
    editor.ui.registry.addButton('accordion', {
      text: <?= $js('Accordion') ?>,
      tooltip: <?= $js('Insert an accordion (3 items; you can delete or copy them)') ?>,
      onAction: function () {
        editor.insertContent('<div class="accordion">' + item(1) + item(2) + item(3) + '</div><p>&nbsp;</p>');
      }
    });
    /* ---------- Iframe (Google Maps, YouTube etc.) ---------- */
    // Din codul lipit se păstrează doar adresa, lățimea și înălțimea; iframe-ul se reface curat.
    var parseEmbed = function (raw) {
      raw = (raw || '').trim();
      var tag = raw.match(/<iframe[^>]*>/i);
      var src = '', w = '', h = '';
      if (tag) {
        var m = tag[0].match(/\ssrc\s*=\s*(["'])(.*?)\1/i);
        src = m ? m[2] : '';
        var mh = tag[0].match(/\sheight\s*=\s*["']?(\d+)/i); h = mh ? mh[1] : '';
        var mw = tag[0].match(/\swidth\s*=\s*["']?(\d+)/i); w = mw ? mw[1] : '';
      } else if (/^https?:\/\//i.test(raw)) {
        src = raw;
      }
      var tmp = document.createElement('textarea'); tmp.innerHTML = src; src = tmp.value.trim();
      if (!/^https?:\/\//i.test(src)) src = '';
      return {src: src, width: w, height: h};
    };
    var embedHtml = function (src, w, h, full) {
      var a = document.createElement('div');
      var f = document.createElement('iframe');
      f.setAttribute('src', src);
      f.setAttribute('width', w || '600');
      f.setAttribute('height', h || '450');
      f.setAttribute('style', 'border:0;');
      f.setAttribute('allowfullscreen', '');
      f.setAttribute('loading', 'lazy');
      f.setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
      a.className = 'embed' + (full ? ' embed-full' : '');
      a.appendChild(f);
      return a.outerHTML;
    };
    editor.ui.registry.addButton('cmsembed', {
      text: <?= $js('Iframe') ?>,
      tooltip: <?= $js('Insert an iframe (Google map, YouTube video or any other embedded content)') ?>,
      onAction: function () {
        editor.windowManager.open({
          title: <?= $js('Insert iframe') ?>,
          body: {type: 'panel', items: [
            {type: 'textarea', name: 'code', label: <?= $js('Iframe code or address') ?>, placeholder: '<iframe src="https://www.google.com/maps/embed?..." ...></iframe>'},
            {type: 'input', name: 'height', label: <?= $js('Height (px) — empty = from the code') ?>},
            {type: 'checkbox', name: 'full', label: <?= $js('Full width (fits any screen)') ?>}
          ]},
          initialData: {code: '', height: '', full: true},
          buttons: [{type: 'cancel', text: <?= $js('Cancel') ?>}, {type: 'submit', text: <?= $js('Insert') ?>, buttonType: 'primary'}],
          onSubmit: function (api) {
            var d = api.getData(), e = parseEmbed(d.code);
            if (!e.src) {
              editor.notificationManager.open({text: <?= $js('I could not find a valid address (http/https). Paste the <iframe …> code or the link.') ?>, type: 'error', timeout: 5000});
              return;
            }
            var h = parseInt(d.height, 10) || parseInt(e.height, 10) || 450;
            editor.insertContent(embedHtml(e.src, e.width, h, d.full) + '<p>&nbsp;</p>');
            api.close();
          }
        });
      }
    });
    var SLIDERS = <?= json_encode(array_map(fn($x) => ['value' => (string)$x['id'], 'text' => $x['name']], $sliders), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP) ?>;
    editor.ui.registry.addButton('cmsslider', {
      text: <?= $js('Slider') ?>,
      tooltip: <?= $js('Insert a slider (its images follow one another automatically) at this place in the page') ?>,
      onAction: function () {
        if (!SLIDERS.length) {
          editor.notificationManager.open({text: <?= $js('You have no sliders yet. Create one in the “Sliders” section.') ?>, type: 'info', timeout: 5000});
          return;
        }
        editor.windowManager.open({
          title: <?= $js('Insert slider') ?>,
          body: {type: 'panel', items: [{type: 'selectbox', name: 'sid', label: <?= $js('Slider') ?>, items: SLIDERS}]},
          initialData: {sid: SLIDERS[0].value},
          buttons: [{type: 'cancel', text: <?= $js('Cancel') ?>}, {type: 'submit', text: <?= $js('Insert') ?>, buttonType: 'primary'}],
          onSubmit: function (api) {
            editor.insertContent('<p>[slider id=' + api.getData().sid + ']</p>');
            api.close();
          }
        });
      }
    });
    /* ---------- Carduri, secțiuni, containere ---------- */
    var opt = function (list) { return list.map(function (x) { return {value: x[0], text: x[1]}; }); };
    var WIDTHS = ['w-narrow', 'w-medium', 'w-wide'];
    var BGS = ['bg-light', 'bg-accent', 'bg-dark'];
    var PADS = ['pad-sm', 'pad-md', 'pad-lg'];
    var pick = function (el, list, def) {
      for (var i = 0; i < list.length; i++) if (editor.dom.hasClass(el, list[i])) return list[i];
      return def;
    };
    var setOne = function (el, list, value) {
      list.forEach(function (c) { editor.dom.removeClass(el, c); });
      if (value) editor.dom.addClass(el, value);
    };
    var dialog = function (title, okText, items, data, onSubmit) {
      editor.windowManager.open({
        title: title,
        body: {type: 'panel', items: items},
        initialData: data,
        buttons: [{type: 'cancel', text: <?= $js('Cancel') ?>}, {type: 'submit', text: okText, buttonType: 'primary'}],
        onSubmit: function (api) { onSubmit(api.getData()); api.close(); }
      });
    };

    var cardItems = [
      {type: 'checkbox', name: 'shadow', label: <?= $js('With shadow') ?>}
    ];
    var sectionItems = [
      {type: 'selectbox', name: 'bg', label: <?= $js('Background') ?>, items: opt([['', <?= $js('No background') ?>], ['bg-light', <?= $js('Light') ?>], ['bg-accent', <?= $js('Main color') ?>], ['bg-dark', <?= $js('Dark') ?>]])},
      {type: 'selectbox', name: 'pad', label: <?= $js('Space above and below') ?>, items: opt([['pad-sm', <?= $js('Small') ?>], ['pad-md', <?= $js('Medium') ?>], ['pad-lg', <?= $js('Large') ?>]])},
      {type: 'selectbox', name: 'align', label: <?= $js('Text alignment') ?>, items: opt([['', <?= $js('Left') ?>], ['text-center', <?= $js('Centered') ?>]])}
    ];
    var containerItems = [
      {type: 'selectbox', name: 'width', label: <?= $js('Maximum width') ?>, items: opt([['w-narrow', <?= $js('Narrow (640 px)') ?>], ['w-medium', <?= $js('Medium (820 px)') ?>], ['w-wide', <?= $js('Wide (1060 px)') ?>]])},
      {type: 'selectbox', name: 'align', label: <?= $js('Position') ?>, items: opt([['', <?= $js('Centered on the page') ?>], ['align-left', <?= $js('Left') ?>]])}
    ];

    editor.ui.registry.addButton('cmscard', {
      text: <?= $js('Card') ?>,
      tooltip: <?= $js('Insert cards (information boxes)') ?>,
      onAction: function () {
        dialog(<?= $js('Insert cards') ?>, <?= $js('Insert') ?>, [
          {type: 'selectbox', name: 'cols', label: <?= $js('Number of cards per row') ?>, items: opt([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']])}
        ].concat(cardItems), {cols: '3', shadow: true}, function (d) {
          var n = parseInt(d.cols, 10) || 1, html = '';
          for (var i = 1; i <= n; i++) {
            html += '<div class="card' + (d.shadow ? ' card-shadow' : '') + '"><h3>' + <?= $js('Card title') ?> + ' ' + i + '</h3><p>' + <?= $js('The card text.') ?> + '</p></div>';
          }
          editor.insertContent('<div class="cards cols-' + n + '">' + html + '</div><p>&nbsp;</p>');
        });
      }
    });

    editor.ui.registry.addButton('cmssection', {
      text: <?= $js('Section') ?>,
      tooltip: <?= $js('Insert a section (a band across the full page width, with optional background)') ?>,
      onAction: function () {
        dialog(<?= $js('Insert section') ?>, <?= $js('Insert') ?>, sectionItems, {bg: 'bg-light', pad: 'pad-md', align: ''}, function (d) {
          var cls = ['section', d.bg, d.pad, d.align].filter(Boolean).join(' ');
          editor.insertContent('<section class="' + cls + '"><h2>' + <?= $js('Section title') ?> + '</h2><p>' + <?= $js('The section text.') ?> + '</p></section><p>&nbsp;</p>');
        });
      }
    });

    editor.ui.registry.addButton('cmscontainer', {
      text: <?= $js('Container') ?>,
      tooltip: <?= $js('Insert a container (limits the width of the content inside)') ?>,
      onAction: function () {
        dialog(<?= $js('Insert container') ?>, <?= $js('Insert') ?>, containerItems, {width: 'w-medium', align: ''}, function (d) {
          var cls = ['container', d.width, d.align].filter(Boolean).join(' ');
          editor.insertContent('<div class="' + cls + '"><p>' + <?= $js('The container content.') ?> + '</p></div><p>&nbsp;</p>');
        });
      }
    });

    // Buton: text, adresă (link), colțuri rotunjite sau drepte. Culorile se aleg din pagina Aspect.
    var btnItems = [
      {type: 'input', name: 'text', label: <?= $js('Button text') ?>},
      {type: 'input', name: 'url', label: <?= $js('Link (address)') ?>},
      {type: 'checkbox', name: 'round', label: <?= $js('Rounded corners') ?>},
      {type: 'checkbox', name: 'blank', label: <?= $js('Open in a new tab') ?>}
    ];
    var applyBtn = function (el, d) {
      var url = (d.url || '').trim();
      if (/^\s*(javascript|data|vbscript):/i.test(url)) url = '';
      el.textContent = d.text || <?= $js('Button') ?>;
      editor.dom.setAttrib(el, 'href', url || '#');
      d.round ? editor.dom.removeClass(el, 'cms-btn-square') : editor.dom.addClass(el, 'cms-btn-square');
      if (d.blank) { editor.dom.setAttrib(el, 'target', '_blank'); editor.dom.setAttrib(el, 'rel', 'noopener'); }
      else { editor.dom.setAttrib(el, 'target', null); editor.dom.setAttrib(el, 'rel', null); }
    };
    editor.ui.registry.addButton('cmsbutton', {
      text: <?= $js('Button') ?>,
      tooltip: <?= $js('Insert a button (with your own text and a link)') ?>,
      onAction: function () { openBtn(); }
    });
    var openBtn = function () {
      {
        var el = editor.dom.getParent(editor.selection.getNode(), 'a.cms-btn');
        var data = el
          ? {text: el.textContent, url: editor.dom.getAttrib(el, 'href'), round: !editor.dom.hasClass(el, 'cms-btn-square'), blank: editor.dom.getAttrib(el, 'target') === '_blank'}
          : {text: editor.selection.getContent({format: 'text'}) || '', url: '', round: true, blank: false};
        dialog(el ? <?= $js('Button properties') ?> : <?= $js('Insert button') ?>, el ? <?= $js('Apply') ?> : <?= $js('Insert') ?>, btnItems, data, function (d) {
          editor.undoManager.transact(function () {
            if (el) { applyBtn(el, d); return; }
            var tmp = editor.dom.create('a', {'class': 'cms-btn'});
            applyBtn(tmp, d);
            editor.insertContent('<p>' + tmp.outerHTML + '</p>');
          });
        });
      }
    };

    // Schimbă opțiunile blocului în care ai cursorul (cel mai interior: card, secțiune sau container)
    editor.ui.registry.addButton('cmsprops', {
      text: <?= $js('Block properties') ?>,
      tooltip: <?= $js('Change the options of the card, section or container where the cursor is (e.g. the card shadow)') ?>,
      onAction: function () {
        var el = editor.dom.getParent(editor.selection.getNode(), 'a.cms-btn, .embed, .card, .section, .container');
        if (el && el.nodeName === 'A') { openBtn(); return; }
        if (!el) {
          editor.notificationManager.open({text: <?= $js('Put the cursor in a card, a section or a container.') ?>, type: 'info', timeout: 4000});
          return;
        }
        if (editor.dom.hasClass(el, 'embed')) {
          var fr = el.querySelector('iframe');
          dialog(<?= $js('Iframe properties') ?>, <?= $js('Apply') ?>, [
            {type: 'input', name: 'height', label: <?= $js('Height (px)') ?>},
            {type: 'checkbox', name: 'full', label: <?= $js('Full width') ?>}
          ], {height: fr ? (fr.getAttribute('height') || '450') : '450', full: editor.dom.hasClass(el, 'embed-full')}, function (d) {
            editor.undoManager.transact(function () {
              if (fr) fr.setAttribute('height', String(parseInt(d.height, 10) || 450));
              d.full ? editor.dom.addClass(el, 'embed-full') : editor.dom.removeClass(el, 'embed-full');
            });
          });
        } else if (editor.dom.hasClass(el, 'card')) {
          var group = editor.dom.getParent(el, '.cards');
          var items = cardItems.slice();
          if (group) items.push({type: 'checkbox', name: 'all', label: <?= $js('Apply to all cards in the group') ?>});
          dialog(<?= $js('Card properties') ?>, <?= $js('Apply') ?>, items, {shadow: editor.dom.hasClass(el, 'card-shadow'), all: false}, function (d) {
            editor.undoManager.transact(function () {
              var targets = d.all && group ? editor.dom.select('.card', group) : [el];
              targets.forEach(function (c) { d.shadow ? editor.dom.addClass(c, 'card-shadow') : editor.dom.removeClass(c, 'card-shadow'); });
            });
          });
        } else if (editor.dom.hasClass(el, 'section')) {
          dialog(<?= $js('Section properties') ?>, <?= $js('Apply') ?>, sectionItems,
            {bg: pick(el, BGS, ''), pad: pick(el, PADS, 'pad-md'), align: editor.dom.hasClass(el, 'text-center') ? 'text-center' : ''},
            function (d) {
              editor.undoManager.transact(function () {
                setOne(el, BGS, d.bg); setOne(el, PADS, d.pad); setOne(el, ['text-center'], d.align);
              });
            });
        } else {
          dialog(<?= $js('Container properties') ?>, <?= $js('Apply') ?>, containerItems,
            {width: pick(el, WIDTHS, 'w-medium'), align: editor.dom.hasClass(el, 'align-left') ? 'align-left' : ''},
            function (d) {
              editor.undoManager.transact(function () {
                setOne(el, WIDTHS, d.width); setOne(el, ['align-left'], d.align);
              });
            });
        }
      }
    });

    // În editor elementele sunt mereu deschise, ca să poți scrie în ele;
    // la salvare atributul "open" se scoate, deci pe site pornesc închise.
    var openAll = function () {
      var b = editor.getBody();
      if (!b) return;
      b.querySelectorAll('details').forEach(function (d) { if (!d.hasAttribute('open')) d.setAttribute('open', ''); });
    };
    editor.on('init SetContent NodeChange', openAll);
    editor.on('GetContent', function (e) {
      if (typeof e.content === 'string') {
        e.content = e.content.replace(/(<details\b[^>]*?)\s+open(?:="[^"]*")?(?=[\s>\/])/g, '$1');
      }
    });
  },
  convert_urls: false,
  relative_urls: false,
  image_caption: true,
  automatic_uploads: true,
  images_upload_handler: function (blobInfo) {
    return new Promise(function (resolve, reject) {
      var fd = new FormData();
      fd.append('file', blobInfo.blob(), blobInfo.filename());
      fd.append('csrf', <?= json_encode(csrf_token()) ?>);
      fetch(<?= json_encode(aurl(['a' => 'upload_inline'])) ?>, {method: 'POST', body: fd, credentials: 'same-origin'})
        .then(function (r) { return r.json().then(function (j) { return {ok: r.ok, j: j}; }); })
        .then(function (x) { x.ok && x.j.location ? resolve(x.j.location) : reject((x.j && x.j.error) || <?= $js('Upload failed') ?>); })
        .catch(function () { reject(<?= $js('Upload failed') ?>); });
    });
  }
});
</script>
