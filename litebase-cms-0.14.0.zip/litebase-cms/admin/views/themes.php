<div class="top"><h1><?= e(t('Themes')) ?></h1></div>

<p class="muted"><?= t('A theme is a folder in %s that decides how the site looks (header, menu, pages, footer). The colors from “Appearance” apply on top of the active theme. How to make a theme is described in %s.', '<code>themes/</code>', '<code>THEMES.md</code>') ?></p>

<div class="card" style="padding:0">
<table>
  <thead><tr><th><?= e(t('Theme')) ?></th><th><?= e(t('Version')) ?></th><th><?= e(t('Author')) ?></th><th></th></tr></thead>
  <tbody>
  <?php foreach ($themes as $th): ?>
    <tr>
      <td>
        <strong><?= e($th['name']) ?></strong> <?= $th['slug'] === $active ? '<span class="badge">' . e(t('active')) . '</span>' : '' ?>
        <div class="muted"><?= e($th['description']) ?> <span>(themes/<?= e($th['slug']) ?>/)</span></div>
      </td>
      <td class="muted"><?= e($th['version']) ?></td>
      <td class="muted"><?= e($th['author']) ?></td>
      <td class="act">
        <?php if ($th['slug'] !== $active): ?>
          <form method="post" action="<?= e(aurl(['a' => 'theme_activate'])) ?>"><?= csrf_field() ?><input type="hidden" name="slug" value="<?= e($th['slug']) ?>"><button class="btn sm"><?= e(t('Activate')) ?></button></form>
          <?php if ($th['slug'] !== 'default'): ?>
          <form method="post" action="<?= e(aurl(['a' => 'theme_delete'])) ?>" onsubmit="return confirm(<?= e(json_encode(t('Delete the theme “%s” (folder themes/%s/)?', $th['name'], $th['slug']))) ?>)"><?= csrf_field() ?><input type="hidden" name="slug" value="<?= e($th['slug']) ?>"><button class="btn danger sm"><?= e(t('Delete')) ?></button></form>
          <?php endif; ?>
        <?php endif; ?>
        <form method="post" action="<?= e(aurl(['a' => 'theme_duplicate'])) ?>" onsubmit="var n=prompt(<?= e(json_encode(t('Name of the new theme (a copy of “%s”):', $th['name']))) ?>); if(!n) return false; this.name.value=n; return true;"><?= csrf_field() ?><input type="hidden" name="from" value="<?= e($th['slug']) ?>"><input type="hidden" name="name" value=""><button class="btn ghost sm"><?= e(t('Duplicate')) ?></button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>

<div class="card" style="max-width:640px;margin-top:20px">
  <h2><?= e(t('Install a theme (.zip)')) ?></h2>
  <?php if ($zip): ?>
  <form method="post" enctype="multipart/form-data" action="<?= e(aurl(['a' => 'theme_install'])) ?>" onsubmit="return confirm(<?= e(json_encode(t('Themes contain PHP code. Install only themes from people you trust. Continue?'))) ?>)">
    <?= csrf_field() ?>
    <div class="field"><input type="file" name="theme_zip" accept=".zip" required></div>
    <button class="btn" type="submit"><?= e(t('Install')) ?></button>
    <div class="help" style="margin-top:8px"><?= t('%sWarning:%s a theme runs PHP code on your server. Install only themes you made yourself or received from someone you trust. A theme must contain %s, %s, %s, %s and %s.', '<strong>', '</strong>', '<code>layout.php</code>', '<code>page.php</code>', '<code>home.php</code>', '<code>404.php</code>', '<code>style.css</code>') ?></div>
  </form>
  <?php else: ?>
  <p class="muted"><?= t('The server does not have the PHP “zip” extension, so installing from an archive is not available. Upload the theme folder to %s over FTP; it appears in the list automatically.', '<code>themes/</code>') ?></p>
  <?php endif; ?>
</div>
