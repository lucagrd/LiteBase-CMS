<?php
$a = (string)($_GET['a'] ?? 'pages');
$on = fn(array $names) => in_array($a, $names, true) ? 'on' : '';
?><!doctype html>
<html lang="<?= e(i18n_lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e(t('Administration')) ?></title>
<link rel="stylesheet" href="<?= e(url('admin/admin.css')) ?>">
</head>
<body>
<div class="shell">
  <aside class="side">
    <div class="brand"><?= e(t('Administration')) ?></div>
    <nav>
      <a class="<?= $on(['pages', 'page_edit']) ?>" href="<?= e(aurl(['a' => 'pages'])) ?>"><?= e(t('Pages')) ?></a>
      <a class="<?= $on(['slides', 'slider_edit', 'slide_edit']) ?>" href="<?= e(aurl(['a' => 'slides'])) ?>"><?= e(t('Sliders')) ?></a>
      <a class="<?= $on(['theme']) ?>" href="<?= e(aurl(['a' => 'theme'])) ?>"><?= e(t('Appearance')) ?></a>
      <a class="<?= $on(['themes']) ?>" href="<?= e(aurl(['a' => 'themes'])) ?>"><?= e(t('Themes')) ?></a>
      <a class="<?= $on(['settings']) ?>" href="<?= e(aurl(['a' => 'settings'])) ?>"><?= e(t('Settings')) ?></a>
      <a href="<?= e(route(default_lang() . '/')) ?>" target="_blank" rel="noopener"><?= e(t('View site ↗')) ?></a>
      <a href="<?= e(aurl(['a' => 'logout'])) ?>"><?= e(t('Log out')) ?></a>
    </nav>
    <div class="foot">
      <div style="margin-bottom:6px">LiteBase CMS v<?= e(CMS_VERSION) ?></div>
      <?php if (cfg('credit')): ?>Designed and built by <?= e(cfg('credit_name')) ?>. <a href="mailto:<?= e(cfg('credit_email')) ?>">Send email</a><?php endif; ?>
    </div>
  </aside>
  <main class="main">
    <?php if (!empty($flash)): ?><div class="flash <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
    <?= $content ?>
  </main>
</div>
</body>
</html>
