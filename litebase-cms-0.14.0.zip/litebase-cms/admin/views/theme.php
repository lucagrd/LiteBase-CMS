<div class="top">
  <h1><?= e(t('Appearance')) ?></h1>
</div>
<p class="muted" style="margin-top:-8px"><?= e(t('Choose the colors for each element of the site. The preview on the right updates instantly — you can hover over the menu and links or click them to see the hover and click colors.')) ?></p>

<form method="post" action="<?= e(aurl(['a' => 'theme_save'])) ?>" id="theme-form">
  <?= csrf_field() ?>
  <div class="theme-cols">

    <div class="theme-fields">
      <?php foreach ($groups as $g): ?>
      <div class="card">
        <h2><?= e($g['title']) ?></h2>
        <div class="cgrid">
          <?php foreach ($g['fields'] as $f): $v = $values[$f['key']]; ?>
          <div class="cf">
            <label for="t_<?= e($f['key']) ?>"><?= e($f['label']) ?></label>
            <div class="cfrow">
              <?php if ($f['type'] === 'color'): ?>
                <input type="color" id="t_<?= e($f['key']) ?>" name="t[<?= e($f['key']) ?>]" value="<?= e($v) ?>"
                       data-key="<?= e($f['key']) ?>" data-var="<?= e($f['var']) ?>" data-type="color" data-default="<?= e($f['default']) ?>">
                <input type="text" class="hex" value="<?= e($v) ?>" maxlength="7" spellcheck="false" aria-label="<?= e(t('Color code')) ?>">
              <?php elseif ($f['type'] === 'px'): ?>
                <input type="number" id="t_<?= e($f['key']) ?>" name="t[<?= e($f['key']) ?>]" value="<?= e($v) ?>" min="<?= (int)$f['min'] ?>" max="<?= (int)$f['max'] ?>" step="1"
                       data-key="<?= e($f['key']) ?>" data-var="<?= e($f['var']) ?>" data-type="px" data-default="<?= e($f['default']) ?>" style="width:90px">
              <?php else: ?>
                <select id="t_<?= e($f['key']) ?>" name="t[<?= e($f['key']) ?>]"
                        data-key="<?= e($f['key']) ?>" data-var="<?= e($f['var']) ?>" data-type="underline" data-default="<?= e($f['default']) ?>">
                  <option value="none" <?= $v === 'none' ? 'selected' : '' ?>><?= e(t('No underline')) ?></option>
                  <option value="always" <?= $v === 'always' ? 'selected' : '' ?>><?= e(t('Always underlined')) ?></option>
                  <option value="hover" <?= $v === 'hover' ? 'selected' : '' ?>><?= e(t('Underlined only on hover')) ?></option>
                </select>
              <?php endif; ?>
              <button type="button" class="rst" title="<?= e(t('Reset to the default value')) ?>" aria-label="<?= e(t('Reset to the default value')) ?>">↺</button>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <div class="theme-preview">
      <div class="card sticky">
        <h2><?= e(t('Preview')) ?></h2>
        <div class="presets">
          <span class="muted"><?= e(t('Ready-made themes:')) ?></span>
          <?php foreach ($presets as $p): ?>
            <button type="button" class="btn ghost sm preset" data-preset="<?= e($p['id']) ?>"><?= e($p['label']) ?></button>
          <?php endforeach; ?>
        </div>
        <div class="pv-wrap"><iframe id="pv" title="<?= e(t('Preview')) ?>" tabindex="-1"></iframe></div>
        <div class="pv-actions">
          <button class="btn" type="submit"><?= e(t('Save appearance')) ?></button>
          <a class="muted" href="<?= e(route(default_lang() . '/')) ?>" target="_blank" rel="noopener"><?= e(t('View site ↗')) ?></a>
        </div>
      </div>
    </div>

  </div>
</form>

<script>
(function () {
  var PRESETS = <?= json_encode(array_column($presets, 'values', 'id'), JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT) ?>;
  var DECO = {always: ['underline', 'underline'], hover: ['none', 'underline'], none: ['none', 'none']};
  var PV_WIDTH = 1000, PV_HEIGHT = 700;

  var form = document.getElementById('theme-form');
  var frame = document.getElementById('pv');
  var wrap = frame.parentNode;
  var fields = form.querySelectorAll('[data-var]');

  frame.style.width = PV_WIDTH + 'px';
  frame.style.height = PV_HEIGHT + 'px';
  frame.srcdoc = <?= json_encode(theme_preview_html()) ?>;

  function scale() {
    var k = wrap.clientWidth / PV_WIDTH;
    frame.style.transform = 'scale(' + k + ')';
    wrap.style.height = Math.round(PV_HEIGHT * k) + 'px';
  }
  window.addEventListener('resize', scale);
  scale();

  function apply(el) {
    var d = frame.contentDocument;
    if (!d || !d.documentElement) return;
    var root = d.documentElement.style, name = el.dataset.var;
    if (el.dataset.type === 'underline') {
      var x = DECO[el.value] || DECO.none;
      root.setProperty(name, x[0]);
      root.setProperty(name + '-hover', x[1]);
    } else if (el.dataset.type === 'px') {
      root.setProperty(name, (parseInt(el.value, 10) || 0) + 'px');
    } else {
      root.setProperty(name, el.value);
    }
  }
  function applyAll() { fields.forEach(apply); }
  // înălțimea iframe-ului urmărește conținutul (inclusiv subsolul), chiar dacă deschizi/închizi accordionul
  function fit() {
    var d = frame.contentDocument;
    if (!d || !d.documentElement) return;
    var h = d.documentElement.scrollHeight;
    if (h && h !== PV_HEIGHT) { PV_HEIGHT = h; frame.style.height = h + 'px'; scale(); }
  }
  frame.addEventListener('load', function () {
    applyAll();
    fit();
    if (frame.contentWindow.ResizeObserver) new frame.contentWindow.ResizeObserver(fit).observe(frame.contentDocument.body);
  });

  function setValue(el, val) {
    el.value = val;
    var hex = el.parentNode.querySelector('.hex');
    if (hex) hex.value = val;
    apply(el);
  }

  fields.forEach(function (el) {
    var hex = el.parentNode.querySelector('.hex');
    el.addEventListener('input', function () { if (hex) hex.value = el.value; apply(el); });
    el.addEventListener('change', function () { apply(el); });
    if (hex) {
      hex.addEventListener('input', function () {
        if (/^#[0-9a-fA-F]{6}$/.test(hex.value)) { el.value = hex.value.toLowerCase(); apply(el); }
      });
      hex.addEventListener('blur', function () { hex.value = el.value; });
    }
    el.parentNode.querySelector('.rst').addEventListener('click', function () { setValue(el, el.dataset.default); });
  });

  form.querySelectorAll('.preset').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = PRESETS[b.dataset.preset] || {};
      fields.forEach(function (el) { setValue(el, p[el.dataset.key] !== undefined ? p[el.dataset.key] : el.dataset.default); });
    });
  });
})();
</script>
