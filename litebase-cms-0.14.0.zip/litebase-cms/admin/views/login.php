<div class="card">
  <h2><?= e(t('Login')) ?></h2>
  <?php if ($err): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>
  <form method="post" action="<?= e(aurl(['a' => 'login'])) ?>">
    <?= csrf_field() ?>
    <div class="field"><label for="u"><?= e(t('Username')) ?></label><input type="text" id="u" name="username" autofocus autocomplete="username"></div>
    <div class="field"><label for="p"><?= e(t('Password')) ?></label><input type="password" id="p" name="password" autocomplete="current-password"></div>
    <button class="btn" type="submit"><?= e(t('Sign in')) ?></button>
  </form>
</div>
