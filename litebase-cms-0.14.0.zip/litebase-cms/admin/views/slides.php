<div class="top">
  <h1><?= e(t('Sliders')) ?></h1>
  <a class="btn" href="<?= e(aurl(['a' => 'slider_edit'])) ?>"><?= e(t('+ New slider')) ?></a>
</div>

<p class="muted"><?= e(t('A slider is a group of images that follow one another automatically. Images are uploaded from each slider’s own page and belong only to it. You then choose the slider in any page (the “Slider” field of the page or the “Slider” button in the editor).')) ?></p>

<div class="card" style="padding:0">
<table>
  <thead><tr><th></th><th><?= e(t('Name')) ?></th><th><?= e(t('Images')) ?></th><th><?= e(t('Status')) ?></th><th></th></tr></thead>
  <tbody>
  <?php foreach ($sliders as $r): ?>
    <tr>
      <td><?php if ($r['cover']): ?><img class="thumb" src="<?= e(url('uploads/' . $r['cover'])) ?>" alt=""><?php endif; ?></td>
      <td><strong><?= e($r['name']) ?></strong><div class="muted"><?= e(t('code for text:')) ?> <code>[slider id=<?= (int)$r['id'] ?>]</code></div></td>
      <td><?= (int)$r['n'] ?></td>
      <td><?= (int)$r['active'] ? '<span class="badge">' . e(t('enabled')) . '</span>' : '<span class="badge off">' . e(t('disabled')) . '</span>' ?></td>
      <td class="act">
        <a class="btn ghost sm" href="<?= e(aurl(['a' => 'slider_edit', 'id' => $r['id']])) ?>"><?= e(t('Edit')) ?></a>
        <form method="post" action="<?= e(aurl(['a' => 'slider_delete'])) ?>" onsubmit="return confirm(<?= e(json_encode(t('Delete the slider and all its images?'))) ?>)"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn danger sm"><?= e(t('Delete')) ?></button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$sliders): ?>
    <tr><td colspan="5" class="muted"><?= e(t('You have no sliders yet. Click “+ New slider”.')) ?></td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
