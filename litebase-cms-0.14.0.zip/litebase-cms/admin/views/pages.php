<div class="top">
  <h1><?= e(t('Pages')) ?></h1>
  <a class="btn" href="<?= e(aurl(['a' => 'page_edit', 'lang' => $lang])) ?>">+ <?= e(t('New page')) ?></a>
</div>

<div class="tabs">
  <?php foreach (langs() as $code => $label): ?>
    <a class="<?= $code === $lang ? 'on' : '' ?>" href="<?= e(aurl(['a' => 'pages', 'lang' => $code])) ?>"><?= e($label) ?></a>
  <?php endforeach; ?>
</div>

<div class="card" style="padding:0">
<table>
  <thead><tr><th><?= e(t('Title')) ?></th><th><?= e(t('Address')) ?></th><th><?= e(t('Menu')) ?></th><th><?= e(t('Status')) ?></th><th></th></tr></thead>
  <tbody>
  <?php if ($home): ?>
    <tr>
      <td><strong><?= e($home['title']) ?></strong> <span class="badge"><?= e(t('start page')) ?></span></td>
      <td class="muted"><a href="<?= e(page_url($home)) ?>" target="_blank" rel="noopener"><?= e(page_url($home)) ?></a></td>
      <td><?= (int)$home['in_menu'] ? '✓' : '—' ?></td>
      <td><?= (int)$home['active'] ? '<span class="badge">' . e(t('active')) . '</span>' : '<span class="badge off">' . e(t('hidden')) . '</span>' ?></td>
      <td class="act"><a class="btn ghost sm" href="<?= e(aurl(['a' => 'page_edit', 'id' => $home['id']])) ?>"><?= e(t('Edit')) ?></a></td>
    </tr>
  <?php endif; ?>
  <?php foreach ($tree as $p): ?>
    <tr>
      <td style="padding-left:<?= 10 + $p['depth'] * 24 ?>px"><?= $p['depth'] ? '↳ ' : '' ?><?= e($p['title']) ?></td>
      <td class="muted"><a href="<?= e(page_url($p)) ?>" target="_blank" rel="noopener"><?= e(page_url($p)) ?></a></td>
      <td><?= (int)$p['in_menu'] ? '✓' : '—' ?></td>
      <td>
        <?php $st = page_state($p); ?>
        <?php if ($st === 'live'): ?><span class="badge"><?= e(t('active')) ?></span>
        <?php elseif ($st === 'hidden'): ?><span class="badge off"><?= e(t('hidden')) ?></span>
        <?php elseif ($st === 'scheduled'): ?><span class="badge warn"><?= e(t('scheduled')) ?></span>
        <?php else: ?><span class="badge off"><?= e(t('expired')) ?></span><?php endif; ?>
        <?php if ($p['visible_from'] !== '' || $p['visible_until'] !== ''): ?>
          <span class="sub-dates"><?= $p['visible_from'] !== '' ? e(t('from %s', date('d.m.Y H:i', strtotime($p['visible_from'])))) : '' ?><?= $p['visible_until'] !== '' ? ' ' . e(t('until %s', date('d.m.Y H:i', strtotime($p['visible_until'])))) : '' ?></span>
        <?php endif; ?>
      </td>
      <td class="act">
        <form method="post" action="<?= e(aurl(['a' => 'page_move'])) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="dir" value="up"><button class="btn ghost sm" title="<?= e(t('Move up')) ?>">↑</button></form>
        <form method="post" action="<?= e(aurl(['a' => 'page_move'])) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="dir" value="down"><button class="btn ghost sm" title="<?= e(t('Move down')) ?>">↓</button></form>
        <a class="btn ghost sm" href="<?= e(aurl(['a' => 'page_edit', 'lang' => $lang, 'parent' => $p['id']])) ?>">+ <?= e(t('Subpage')) ?></a>
        <a class="btn ghost sm" href="<?= e(aurl(['a' => 'page_edit', 'id' => $p['id']])) ?>"><?= e(t('Edit')) ?></a>
        <form method="post" action="<?= e(aurl(['a' => 'page_delete'])) ?>" onsubmit="return confirm(<?= e(json_encode(t('Delete the page "%s"?', $p['title']))) ?>)"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$p['id'] ?>"><button class="btn danger sm"><?= e(t('Delete')) ?></button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$tree): ?>
    <tr><td colspan="5" class="muted"><?= e(t('There are no other pages in this language yet.')) ?></td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
