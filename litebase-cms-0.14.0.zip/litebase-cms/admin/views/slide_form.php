<div class="top">
  <h1><?= e(t('Edit image')) ?> <span class="badge"><?= e($slider['name']) ?></span></h1>
  <a href="<?= e(aurl(['a' => 'slider_edit', 'id' => $slider['id']])) ?>"><?= e(t('← Back to slider')) ?></a>
</div>

<form method="post" enctype="multipart/form-data" action="<?= e(aurl(['a' => 'slide_save'])) ?>" class="card" style="max-width:640px">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$slide['id'] ?>">

  <div class="field">
    <label for="image"><?= e(t('Replace the image (leave empty to keep it)')) ?></label>
    <?php if ($slide['image']): ?><img class="thumb" style="width:220px;height:124px;display:block;margin-bottom:8px" src="<?= e(url('uploads/' . $slide['image'])) ?>" alt=""><?php endif; ?>
    <input type="file" id="image" name="image" accept="image/*">
    <div class="help"><?= e(t('Recommended: a wide format, for example 1600 × 600 px.')) ?></div>
  </div>
  <div class="field"><label for="title"><?= e(t('Title (optional)')) ?></label><input type="text" id="title" name="title" value="<?= e($slide['title']) ?>"></div>
  <div class="field"><label for="text"><?= e(t('Short text (optional)')) ?></label><textarea id="text" name="text" rows="2"><?= e($slide['text']) ?></textarea></div>
  <div class="field"><label for="link"><?= e(t('Link (optional)')) ?></label><input type="text" id="link" name="link" value="<?= e($slide['link']) ?>" placeholder="<?= e(t('e.g. /en/contact or https://…')) ?>"></div>
  <label class="check"><input type="checkbox" name="active" value="1" <?= (int)$slide['active'] ? 'checked' : '' ?>> <?= e(t('Image is active')) ?></label>
  <button class="btn" type="submit"><?= e(t('Save')) ?></button>
</form>
