<?php if (cfg('credit')): ?>
<div class="credit">Designed and built by <?= e(cfg('credit_name')) ?>. <a href="mailto:<?= e(cfg('credit_email')) ?>">Send email</a></div>
<?php endif; ?>
