<!doctype html>
<html lang="<?= e(i18n_lang()) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?= e(t('Administration')) ?></title>
<link rel="stylesheet" href="<?= e(url('admin/admin.css')) ?>">
</head>
<body>
<div class="bare"><div class="box">
<?php if (!empty($flash)): ?><div class="flash <?= e($flash['type']) ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
<?= $content ?>
<?php require __DIR__ . '/credit.php'; ?>
</div></div>
</body>
</html>
