<?php $active = langs(); ?>
<div class="top"><h1><?= e(t('Settings')) ?></h1></div>

<div class="card" id="limbi">
  <h2><?= e(t('Languages')) ?></h2>
  <table style="margin-bottom:12px">
    <tbody>
    <?php foreach ($active as $code => $label): ?>
      <tr>
        <td><strong><?= e($label) ?></strong> <span class="muted">(<?= e($code) ?>)</span><?= default_lang() === $code ? ' <span class="badge">' . e(t('default')) . '</span>' : '' ?></td>
        <td class="act">
          <?php if (count($active) > 1): ?>
          <form method="post" action="<?= e(aurl(['a' => 'lang_remove'])) ?>" style="display:inline" onsubmit="return confirm(<?= e(json_encode(t('Remove the language “%s” from the site? Its content is kept and comes back if you add it again.', $label))) ?>)">
            <?= csrf_field() ?><input type="hidden" name="code" value="<?= e($code) ?>"><button class="btn danger sm"><?= e(t('Delete')) ?></button>
          </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php $inactive = array_diff_key(known_langs(), $active); ?>
  <form method="post" action="<?= e(aurl(['a' => 'lang_add'])) ?>">
    <?= csrf_field() ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;align-items:end">
      <?php if ($inactive): ?>
      <div class="field" style="margin:0"><label for="pick"><?= e(t('Add a known language')) ?></label>
        <select id="pick" name="pick"><option value=""><?= e(t('— choose —')) ?></option>
          <?php foreach ($inactive as $c => $l): ?><option value="<?= e($c) ?>"><?= e($l) ?> (<?= e($c) ?>)</option><?php endforeach; ?>
        </select></div>
      <?php endif; ?>
      <div class="field" style="margin:0"><label for="lcode"><?= e(t('…or a new language: code')) ?></label><input type="text" id="lcode" name="code" maxlength="9" placeholder="<?= e(t('e.g. pl')) ?>"></div>
      <div class="field" style="margin:0"><label for="lname"><?= e(t('Name')) ?></label><input type="text" id="lname" name="name" maxlength="40" placeholder="<?= e(t('e.g. Polski')) ?>"></div>
      <div><button class="btn" type="submit"><?= e(t('Add language')) ?></button></div>
    </div>
    <div class="help" style="margin-top:8px"><?= e(t('You can add as many languages as you like. Deleting a language only removes it from the site: its pages, footer and settings stay saved and come back when you add the language again with the same code.')) ?></div>
  </form>
</div>

<form method="post" action="<?= e(aurl(['a' => 'settings'])) ?>">
  <?= csrf_field() ?>

  <div class="card">
    <div class="field" style="max-width:260px;margin-bottom:0">
      <label for="default_lang"><?= e(t('Default language')) ?></label>
      <select id="default_lang" name="default_lang">
        <?php foreach ($active as $code => $label): ?>
          <option value="<?= e($code) ?>" <?= default_lang() === $code ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
      <?php $ui = lang_files(); ?>
      <div class="help"><?= e(t('The default language is also the language of this administration, if it has a file in the lang/ folder (available: %s); otherwise the administration is in English. The content you write stays in the language it was written in.', implode(', ', array_keys($ui)))) ?></div>
    </div>
  </div>

  <div class="card">
    <h2><?= e(t('Footer map (Google Maps)')) ?></h2>
    <label class="check"><input type="checkbox" name="map_on" value="1" <?= setting('map_on', '0') === '1' ? 'checked' : '' ?>> <?= e(t('Show the map in the site footer')) ?></label>
    <div class="field" style="margin-top:10px">
      <label for="map_embed"><?= e(t('Google Maps embed code (optional)')) ?></label>
      <textarea id="map_embed" name="map_embed" rows="3" placeholder='<iframe src="https://www.google.com/maps/embed?pb=..." ...></iframe>'><?= e(setting('map_embed', '')) ?></textarea>
      <div class="help"><?= e(t('In Google Maps: Share → Embed a map → Copy HTML, then paste the whole code here. Only the map address is kept; if filled in, it takes priority over the coordinates. Leave empty to use the coordinates below.')) ?></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-top:10px">
      <div class="field" style="margin:0"><label for="map_lat"><?= e(t('Latitude')) ?></label><input type="text" id="map_lat" name="map_lat" value="<?= e(setting('map_lat', '')) ?>" placeholder="<?= e(t('e.g. 44.4268')) ?>"></div>
      <div class="field" style="margin:0"><label for="map_lng"><?= e(t('Longitude')) ?></label><input type="text" id="map_lng" name="map_lng" value="<?= e(setting('map_lng', '')) ?>" placeholder="<?= e(t('e.g. 26.1025')) ?>"></div>
      <div class="field" style="margin:0"><label for="map_zoom"><?= e(t('Zoom (1–20)')) ?></label><input type="number" id="map_zoom" name="map_zoom" min="1" max="20" value="<?= (int)setting('map_zoom', '15') ?>"></div>
      <div class="field" style="margin:0"><label for="map_height"><?= e(t('Map height (px)')) ?></label><input type="number" id="map_height" name="map_height" min="150" max="800" step="10" value="<?= (int)setting('map_height', '300') ?>"></div>
    </div>
    <div class="help" style="margin-top:8px"><?= e(t('Coordinates (alternative): in Google Maps right-click the place you want and choose the coordinates (copied as “44.4268, 26.1025”). You can paste both in the Latitude field. The footer adjusts its height to the content (map + text).')) ?></div>
  </div>

  <div class="card">
    <h2><?= e(t('Addresses (URL)')) ?></h2>
    <label class="check"><input type="checkbox" name="url_rewrite" value="1" <?= rewrite_on() ? 'checked' : '' ?>> <?= e(t('URL Rewriting enabled')) ?></label>
    <div class="help"><?= t('Enabled: clean addresses like %s (needs %s and the %s file on Apache). Disabled: %s, which works on any server. If pages give a 404 error after enabling, uncheck it.', '<code>/en/contact</code>', '<code>mod_rewrite</code>', '<code>.htaccess</code>', '<code>/index.php/en/contact</code>') ?></div>
  </div>

  <?php foreach ($active as $code => $label): ?>
  <div class="card">
    <h2><?= e(t('Site — %s', $label)) ?></h2>
    <div class="field"><label><?= e(t('Site name')) ?></label><input type="text" name="site_name[<?= e($code) ?>]" value="<?= e(setting('site_name_' . $code, '')) ?>"></div>
    <div class="field"><label><?= e(t('Tagline (shown under the name and in Google)')) ?></label><input type="text" name="tagline[<?= e($code) ?>]" value="<?= e(setting('tagline_' . $code, '')) ?>"></div>
    <div class="field"><label><?= e(t('Default keywords (SEO)')) ?></label><input type="text" name="keywords[<?= e($code) ?>]" value="<?= e(setting('keywords_' . $code, '')) ?>" placeholder="<?= e(t('e.g. construction, renovation, estimates')) ?>">
      <div class="help"><?= e(t('Separated by commas. Used on pages that have no keywords of their own.')) ?></div></div>
    <div class="field" style="margin-bottom:0">
      <label for="footer_<?= e($code) ?>"><?= e(t('Footer content')) ?></label>
      <?php $fh = (string)setting('footer_html_' . $code, ''); if (trim($fh) === '' && setting('footer_' . $code, '') !== '') { $fh = '<p style="text-align: center;">' . e(setting('footer_' . $code, '')) . '</p>'; } ?>
      <textarea class="footer-editor" id="footer_<?= e($code) ?>" name="footer_html[<?= e($code) ?>]" rows="6"><?= e($fh) ?></textarea>
      <div class="help"><?= e(t('Here you can put text, images, cards, sections, containers or sliders, as in a page. It appears in the footer of every page in this language, between the map and the credit.')) ?></div>
    </div>
  </div>
  <?php endforeach; ?>

  <button class="btn" type="submit"><?= e(t('Save settings')) ?></button>
</form>
<?php $editorSelector = '.footer-editor'; require __DIR__ . '/_editor.php'; ?>

<form method="post" action="<?= e(aurl(['a' => 'password'])) ?>" class="card" style="max-width:420px;margin-top:24px">
  <?= csrf_field() ?>
  <h2><?= e(t('Change password')) ?></h2>
  <div class="field"><label><?= e(t('Current password')) ?></label><input type="password" name="current_password" autocomplete="current-password"></div>
  <div class="field"><label><?= e(t('New password (at least 8 characters)')) ?></label><input type="password" name="new_password" autocomplete="new-password"></div>
  <button class="btn ghost" type="submit"><?= e(t('Change password')) ?></button>
</form>
