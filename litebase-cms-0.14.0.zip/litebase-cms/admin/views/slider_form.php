<div class="top">
  <h1><?= (int)$slider['id'] ? e(t('Slider: %s', $slider['name'])) : e(t('New slider')) ?></h1>
  <a href="<?= e(aurl(['a' => 'slides'])) ?>"><?= e(t('← Back to sliders')) ?></a>
</div>

<form method="post" enctype="multipart/form-data" action="<?= e(aurl(['a' => 'slider_save'])) ?>" class="card" style="max-width:640px">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$slider['id'] ?>">
  <div class="field"><label for="name"><?= e(t('Slider name (only for you)')) ?></label><input type="text" id="name" name="name" value="<?= e($slider['name']) ?>" required placeholder="<?= e(t('e.g. Company presentation')) ?>"></div>
  <label class="check"><input type="checkbox" name="active" value="1" <?= (int)$slider['active'] ? 'checked' : '' ?>> <?= e(t('Slider is active')) ?></label>
  <div class="field" style="margin-top:12px">
    <label for="images"><?= e(t('Add images to this slider')) ?></label>
    <input type="file" id="images" name="images[]" accept="image/*" multiple>
    <div class="help"><?= e(t('You can choose several images at once. Recommended: a wide format, for example 1600 × 600 px. Title, text and link can be filled in afterwards from “Edit”.')) ?></div>
  </div>
  <button class="btn" type="submit"><?= e(t('Save')) ?></button>
</form>

<?php if ((int)$slider['id']): ?>
<?php if ($usedIn): ?>
  <p class="muted"><?= e(t('Shown at the top of the pages: %s.', implode(', ', array_map(fn($p) => $p['title'] . ' (' . $p['lang'] . ')', $usedIn)))) ?> <?= e(t('Code to insert in text:')) ?> <code>[slider id=<?= (int)$slider['id'] ?>]</code></p>
<?php else: ?>
  <p class="muted"><?= e(t('Code to insert in text:')) ?> <code>[slider id=<?= (int)$slider['id'] ?>]</code> <?= e(t('(or choose it in the “Slider” field of a page).')) ?></p>
<?php endif; ?>
<h2><?= e(t('Slider images')) ?></h2>
<div class="card" style="padding:0">
<table>
  <thead><tr><th><?= e(t('Image')) ?></th><th><?= e(t('Title')) ?></th><th><?= e(t('Link')) ?></th><th><?= e(t('Status')) ?></th><th></th></tr></thead>
  <tbody>
  <?php foreach ($items as $s): ?>
    <tr>
      <td><img class="thumb" src="<?= e(url('uploads/' . $s['image'])) ?>" alt=""></td>
      <td><?= e($s['title']) ?><div class="muted"><?= e(mb_strimwidth($s['text'], 0, 70, '…')) ?></div></td>
      <td class="muted"><?= e($s['link']) ?></td>
      <td><?= (int)$s['active'] ? '<span class="badge">' . e(t('enabled')) . '</span>' : '<span class="badge off">' . e(t('disabled')) . '</span>' ?></td>
      <td class="act">
        <form method="post" action="<?= e(aurl(['a' => 'slide_move'])) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><input type="hidden" name="dir" value="up"><button class="btn ghost sm">↑</button></form>
        <form method="post" action="<?= e(aurl(['a' => 'slide_move'])) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><input type="hidden" name="dir" value="down"><button class="btn ghost sm">↓</button></form>
        <a class="btn ghost sm" href="<?= e(aurl(['a' => 'slide_edit', 'id' => $s['id']])) ?>"><?= e(t('Edit')) ?></a>
        <form method="post" action="<?= e(aurl(['a' => 'slide_delete'])) ?>" onsubmit="return confirm(<?= e(json_encode(t('Delete the image?'))) ?>)"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$s['id'] ?>"><button class="btn danger sm"><?= e(t('Delete')) ?></button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$items): ?>
    <tr><td colspan="5" class="muted"><?= e(t('The slider has no images yet. Add them above.')) ?></td></tr>
  <?php endif; ?>
  </tbody>
</table>
</div>
<?php endif; ?>
