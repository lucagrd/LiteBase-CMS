<?php
declare(strict_types=1);

require __DIR__ . '/../lib/bootstrap.php';
session_boot();

/** Limba interfeței de administrare = limba implicită a siteului (dacă are fișier în lang/), altfel engleza. */
function admin_ui_lang(): string
{
    $files = lang_files();
    $def = (string)setting('default_lang', '');
    if ($def === '') {
        foreach (preg_split('/[,;]\s*/', strtolower((string)($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? ''))) as $p) {
            $c = substr(trim($p), 0, 2);
            if (isset($files[$c])) {
                return $c;
            }
        }
        return isset($files['ro']) ? 'ro' : 'en';
    }
    $def = default_lang();
    return isset($files[$def]) || isset($files[explode('-', $def)[0]]) ? $def : 'en';
}
i18n_lang(admin_ui_lang());

/* ------------------------------------------------------------------ */
/* Helperi pentru administrare                                         */
/* ------------------------------------------------------------------ */

function aurl(array $q = []): string
{
    return url('admin/') . ($q ? '?' . http_build_query($q) : '');
}

function render(string $view, array $vars = []): void
{
    extract($vars);
    $flash = flash();
    ob_start();
    require __DIR__ . '/views/' . $view . '.php';
    $content = ob_get_clean();
    if (in_array($view, ['login', 'setup'], true)) {
        require __DIR__ . '/views/bare.php';
    } else {
        require __DIR__ . '/views/layout.php';
    }
    exit;
}

function current_lang(): string
{
    $l = langs();
    $want = (string)($_GET['lang'] ?? $_POST['lang'] ?? '');
    return isset($l[$want]) ? $want : default_lang();
}

function require_login(): void
{
    if (!logged_in()) {
        redirect(aurl(['a' => 'login']));
    }
}

function renumber_siblings(string $lang, ?int $parent): void
{
    $st = db()->prepare('SELECT id FROM pages WHERE lang = ? AND is_home = 0 AND parent_id IS ? ORDER BY position, id');
    $st->execute([$lang, $parent]);
    $n = 1;
    foreach ($st->fetchAll() as $r) {
        db()->prepare('UPDATE pages SET position = ? WHERE id = ?')->execute([$n++, $r['id']]);
    }
}

function unique_slug(string $lang, ?int $parent, string $slug, int $exceptId = 0): string
{
    $base = $slug;
    $i = 2;
    while (true) {
        $st = db()->prepare('SELECT id FROM pages WHERE lang = ? AND slug = ? AND is_home = 0 AND parent_id IS ? AND id != ?');
        $st->execute([$lang, $slug, $parent, $exceptId]);
        if (!$st->fetch()) {
            return $slug;
        }
        $slug = $base . '-' . $i++;
    }
}

/* ------------------------------------------------------------------ */
/* Rutare                                                              */
/* ------------------------------------------------------------------ */

$a = (string)($_GET['a'] ?? 'pages');

$usersCount = (int)db()->query('SELECT COUNT(*) AS c FROM users')->fetch()['c'];
if ($usersCount === 0) {
    $a = 'setup';
}
if (!in_array($a, ['login', 'setup'], true)) {
    require_login();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
}

ensure_home_pages();

switch ($a) {

    /* ---------- cont ---------- */

    case 'setup':
        if ($usersCount > 0) {
            redirect(aurl());
        }
        $err = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $u = trim((string)($_POST['username'] ?? ''));
            $p = (string)($_POST['password'] ?? '');
            $n = trim((string)($_POST['site_name'] ?? ''));
            if ($u === '' || mb_strlen($p) < 8) {
                $err = t('Choose a username and a password of at least 8 characters.');
            } else {
                db()->prepare('INSERT INTO users(username, password_hash) VALUES(?, ?)')
                    ->execute([$u, password_hash($p, PASSWORD_DEFAULT)]);
                set_setting('languages', 'ro,en');
                set_setting('default_lang', 'ro');
                foreach (known_langs() as $code => $_) {
                    set_setting('site_name_' . $code, $n !== '' ? $n : 'Site-ul meu');
                }
                ensure_home_pages();
                session_regenerate_id(true);
                $_SESSION['uid'] = (int)db()->lastInsertId();
                flash(t('The account was created. Welcome!'));
                redirect(aurl());
            }
        }
        render('setup', ['err' => $err]);

    case 'login':
        $err = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $st = db()->prepare('SELECT * FROM users WHERE username = ?');
            $st->execute([trim((string)($_POST['username'] ?? ''))]);
            $u = $st->fetch();
            if ($u && password_verify((string)($_POST['password'] ?? ''), $u['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['uid'] = (int)$u['id'];
                redirect(aurl());
            }
            sleep(1);
            $err = t('Wrong username or password.');
        }
        render('login', ['err' => $err]);

    case 'logout':
        $_SESSION = [];
        session_destroy();
        redirect(aurl(['a' => 'login']));

    /* ---------- pagini ---------- */

    case 'pages':
        $lang = current_lang();
        render('pages', [
            'lang' => $lang,
            'home' => home_page($lang),
            'tree' => page_tree($lang),
        ]);

    case 'page_edit':
        $lang = current_lang();
        $id = (int)($_GET['id'] ?? 0);
        $page = $id ? page_by_id($id) : null;
        if ($id && !$page) {
            flash(t('The page does not exist.'), 'err');
            redirect(aurl());
        }
        if ($page) {
            $lang = $page['lang'];
        }
        $idx = pages_index($lang, true);
        $exclude = $page ? array_merge([(int)$page['id']], descendant_ids($idx, (int)$page['id'])) : [];
        $parents = array_filter(page_tree($lang), fn($p) => !in_array((int)$p['id'], $exclude, true));
        if (!$page) {
            $page = [
                'id' => 0, 'lang' => $lang, 'title' => '', 'slug' => '', 'content' => '',
                'parent_id' => isset($_GET['parent']) ? (int)$_GET['parent'] : null,
                'active' => 1, 'in_menu' => 1, 'is_home' => 0, 'meta_title' => '', 'meta_description' => '',
                'meta_keywords' => '', 'visible_from' => '', 'visible_until' => '', 'slider_id' => 0,
            ];
        }
        render('page_form', [
            'lang' => $lang, 'page' => $page, 'parents' => array_values($parents),
            'files' => $page['id'] ? page_files((int)$page['id']) : [],
            'sliders' => db()->query('SELECT id, name FROM sliders ORDER BY name')->fetchAll(),
        ]);

    case 'page_save':
        $id = (int)($_POST['id'] ?? 0);
        $existing = $id ? page_by_id($id) : null;
        $langs = langs();
        $lang = $existing ? $existing['lang'] : (string)($_POST['lang'] ?? '');
        if (!isset($langs[$lang])) {
            flash(t('Invalid language.'), 'err');
            redirect(aurl());
        }
        $title = trim((string)($_POST['title'] ?? ''));
        if ($title === '') {
            flash(t('The title is required.'), 'err');
            redirect($id ? aurl(['a' => 'page_edit', 'id' => $id]) : aurl(['a' => 'page_edit', 'lang' => $lang]));
        }
        $isHome = $existing ? (int)$existing['is_home'] : 0;
        $parent = null;
        $slug = '';
        if (!$isHome) {
            $parent = (int)($_POST['parent_id'] ?? 0) ?: null;
            if ($parent !== null) {
                $pp = page_by_id($parent);
                $idx = pages_index($lang, true);
                if (!$pp || $pp['lang'] !== $lang || ($existing && ($parent === $id || in_array($parent, descendant_ids($idx, $id), true)))) {
                    $parent = $existing ? parent_of($existing) : null;
                }
            }
            $slug = slugify(trim((string)($_POST['slug'] ?? '')) ?: $title);
            $slug = unique_slug($lang, $parent, $slug, $id);
        }
        // Programarea vizibilității (goală = vizibilă imediat, fără limită). Pagina de start nu se programează.
        $from = $isHome ? '' : parse_local_datetime((string)($_POST['visible_from'] ?? ''));
        $until = $isHome ? '' : parse_local_datetime((string)($_POST['visible_until'] ?? ''));
        $scheduleWarning = '';
        if ($from !== '' && $until !== '' && $until <= $from) {
            $until = '';
            $scheduleWarning = t('The “Visible until” date must be after “Visible from”, so it was not saved.');
        }
        $data = [
            $title, $slug, (string)($_POST['content'] ?? ''),
            isset($_POST['active']) ? 1 : 0, isset($_POST['in_menu']) ? 1 : 0,
            trim((string)($_POST['meta_title'] ?? '')), trim((string)($_POST['meta_description'] ?? '')),
            normalize_keywords((string)($_POST['meta_keywords'] ?? '')), $from, $until,
            date('Y-m-d H:i:s'),
            ($sl = (int)($_POST['slider_id'] ?? 0)) && slider_by_id($sl) ? $sl : 0,
        ];
        if ($existing) {
            if (!$isHome && parent_of($existing) !== $parent) {
                $max = db()->prepare('SELECT COALESCE(MAX(position), 0) + 1 AS m FROM pages WHERE lang = ? AND parent_id IS ?');
                $max->execute([$lang, $parent]);
                $pos = (int)$max->fetch()['m'];
            } else {
                $pos = (int)$existing['position'];
            }
            db()->prepare('UPDATE pages SET title=?, slug=?, content=?, active=?, in_menu=?, meta_title=?, meta_description=?, meta_keywords=?, visible_from=?, visible_until=?, updated_at=?, slider_id=?, parent_id=?, position=? WHERE id=?')
                ->execute(array_merge($data, [$parent, $pos, $id]));
            if (!$isHome && parent_of($existing) !== $parent) {
                renumber_siblings($lang, parent_of($existing));
            }
        } else {
            $max = db()->prepare('SELECT COALESCE(MAX(position), 0) + 1 AS m FROM pages WHERE lang = ? AND parent_id IS ?');
            $max->execute([$lang, $parent]);
            $pos = (int)$max->fetch()['m'];
            db()->prepare('INSERT INTO pages(title, slug, content, active, in_menu, meta_title, meta_description, meta_keywords, visible_from, visible_until, updated_at, slider_id, lang, parent_id, position, is_home)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0)')
                ->execute(array_merge($data, [$lang, $parent, $pos]));
            $id = (int)db()->lastInsertId();
        }

        // descrieri și aliniere pentru fișierele existente
        foreach ((array)($_POST['caption'] ?? []) as $fid => $cap) {
            db()->prepare('UPDATE files SET caption = ? WHERE id = ? AND page_id = ?')
                ->execute([mb_substr(trim((string)$cap), 0, 200), (int)$fid, $id]);
        }
        foreach ((array)($_POST['align'] ?? []) as $fid => $al) {
            if (in_array($al, ['gallery', 'left', 'right', 'center'], true)) {
                db()->prepare('UPDATE files SET align = ? WHERE id = ? AND page_id = ? AND is_image = 1')
                    ->execute([$al, (int)$fid, $id]);
            }
        }
        // fișiere noi
        $errors = [];
        foreach (files_list('files') as $f) {
            try {
                $r = save_upload($f);
                $pos = (int)db()->query('SELECT COALESCE(MAX(position), 0) + 1 AS m FROM files WHERE page_id = ' . $id)->fetch()['m'];
                db()->prepare('INSERT INTO files(page_id, filename, original, is_image, position) VALUES(?,?,?,?,?)')
                    ->execute([$id, $r['filename'], $r['original'], $r['is_image'], $pos]);
            } catch (RuntimeException $ex) {
                $errors[] = $ex->getMessage();
            }
        }
        if ($scheduleWarning !== '') {
            $errors[] = $scheduleWarning;
        }
        if ($errors) {
            flash(t('The page was saved, but: %s', implode(' ', $errors)), 'err');
        } else {
            flash(t('The page was saved.'));
        }
        redirect(aurl(['a' => 'page_edit', 'id' => $id]));

    case 'page_move':
        $p = page_by_id((int)($_POST['id'] ?? 0));
        if ($p && !(int)$p['is_home']) {
            $st = db()->prepare('SELECT id FROM pages WHERE lang = ? AND is_home = 0 AND parent_id IS ? ORDER BY position, id');
            $st->execute([$p['lang'], parent_of($p)]);
            $ids = array_map('intval', array_column($st->fetchAll(), 'id'));
            $i = array_search((int)$p['id'], $ids, true);
            $j = ($_POST['dir'] ?? '') === 'up' ? $i - 1 : $i + 1;
            if ($i !== false && isset($ids[$j])) {
                [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
                foreach ($ids as $n => $pid) {
                    db()->prepare('UPDATE pages SET position = ? WHERE id = ?')->execute([$n + 1, $pid]);
                }
            }
            redirect(aurl(['a' => 'pages', 'lang' => $p['lang']]));
        }
        redirect(aurl());

    case 'page_delete':
        $p = page_by_id((int)($_POST['id'] ?? 0));
        if (!$p) {
            redirect(aurl());
        }
        if ((int)$p['is_home']) {
            flash(t('The start page cannot be deleted.'), 'err');
        } elseif (children_of(pages_index($p['lang'], true), (int)$p['id'])) {
            flash(t('The page has subpages. Delete or move them first.'), 'err');
        } else {
            foreach (page_files((int)$p['id']) as $f) {
                delete_upload($f['filename']);
            }
            db()->prepare('DELETE FROM pages WHERE id = ?')->execute([$p['id']]);
            renumber_siblings($p['lang'], parent_of($p));
            flash(t('The page was deleted.'));
        }
        redirect(aurl(['a' => 'pages', 'lang' => $p['lang']]));

    case 'file_delete':
        $st = db()->prepare('SELECT * FROM files WHERE id = ?');
        $st->execute([(int)($_POST['file_id'] ?? 0)]);
        $f = $st->fetch();
        if ($f) {
            delete_upload($f['filename']);
            db()->prepare('DELETE FROM files WHERE id = ?')->execute([$f['id']]);
            flash(t('The file was deleted.'));
            redirect(aurl(['a' => 'page_edit', 'id' => $f['page_id']]));
        }
        redirect(aurl());

    case 'upload_inline': // imagini inserate direct în editor (TinyMCE)
        header('Content-Type: application/json; charset=utf-8');
        try {
            $f = $_FILES['file'] ?? null;
            if (!$f) {
                throw new RuntimeException(t('No file.'));
            }
            $r = save_upload($f, true, 'inline');
            echo json_encode(['location' => url('uploads/' . $r['filename'])]);
        } catch (RuntimeException $ex) {
            http_response_code(400);
            echo json_encode(['error' => $ex->getMessage()]);
        }
        exit;

    /* ---------- slidere ---------- */

    case 'slides': // lista de slidere
        $rows = db()->query('SELECT r.*, (SELECT COUNT(*) FROM slides s WHERE s.slider_id = r.id) AS n,
                             (SELECT image FROM slides s WHERE s.slider_id = r.id ORDER BY position, id LIMIT 1) AS cover
                             FROM sliders r ORDER BY r.id')->fetchAll();
        render('slides', ['sliders' => $rows]);

    case 'slider_edit':
        $id = (int)($_GET['id'] ?? 0);
        $slider = $id ? slider_by_id($id) : null;
        if ($id && !$slider) {
            redirect(aurl(['a' => 'slides']));
        }
        $slider = $slider ?: ['id' => 0, 'name' => '', 'active' => 1];
        $items = [];
        $usedIn = [];
        if ($id) {
            $st = db()->prepare('SELECT * FROM slides WHERE slider_id = ? ORDER BY position, id');
            $st->execute([$id]);
            $items = $st->fetchAll();
            $st = db()->prepare('SELECT id, title, lang FROM pages WHERE slider_id = ?');
            $st->execute([$id]);
            $usedIn = $st->fetchAll();
        }
        render('slider_form', ['slider' => $slider, 'items' => $items, 'usedIn' => $usedIn]);

    case 'slider_save':
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') {
            flash(t('Give the slider a name.'), 'err');
            redirect(aurl(['a' => 'slider_edit', 'id' => $id]));
        }
        $active = isset($_POST['active']) ? 1 : 0;
        if ($id && slider_by_id($id)) {
            db()->prepare('UPDATE sliders SET name = ?, active = ? WHERE id = ?')->execute([$name, $active, $id]);
        } else {
            db()->prepare('INSERT INTO sliders(name, active) VALUES(?, ?)')->execute([$name, $active]);
            $id = (int)db()->lastInsertId();
        }
        // imaginile încărcate aici aparțin doar acestui slider
        $pos = (int)db()->query('SELECT COALESCE(MAX(position), 0) AS m FROM slides WHERE slider_id = ' . $id)->fetch()['m'];
        $added = 0;
        $errors = [];
        foreach (files_list('images') as $f) {
            try {
                $r = save_upload($f, true, 'slides');
                db()->prepare('INSERT INTO slides(lang, slider_id, image, title, text, link, position, active) VALUES("", ?, ?, "", "", "", ?, 1)')
                    ->execute([$id, $r['filename'], ++$pos]);
                $added++;
            } catch (RuntimeException $ex) {
                $errors[] = $ex->getMessage();
            }
        }
        $msg = t('The slider was saved.') . ($added ? ' ' . t('Images added: %d.', $added) : '');
        if ($errors) {
            flash($msg . ' ' . implode(' ', $errors), 'err');
        } else {
            flash($msg);
        }
        redirect(aurl(['a' => 'slider_edit', 'id' => $id]));

    case 'slider_delete':
        $id = (int)($_POST['id'] ?? 0);
        if (slider_by_id($id)) {
            $st = db()->prepare('SELECT image FROM slides WHERE slider_id = ?');
            $st->execute([$id]);
            foreach ($st->fetchAll() as $r) {
                delete_upload($r['image']);
            }
            db()->prepare('DELETE FROM slides WHERE slider_id = ?')->execute([$id]);
            db()->prepare('DELETE FROM sliders WHERE id = ?')->execute([$id]);
            db()->prepare('UPDATE pages SET slider_id = 0 WHERE slider_id = ?')->execute([$id]);
            flash(t('The slider was deleted.'));
        }
        redirect(aurl(['a' => 'slides']));

    case 'slide_edit': // o imagine dintr-un slider (titlu, text, link, înlocuire imagine)
        $id = (int)($_GET['id'] ?? 0);
        $st = db()->prepare('SELECT * FROM slides WHERE id = ?');
        $st->execute([$id]);
        $slide = $st->fetch();
        if (!$slide || !slider_by_id((int)$slide['slider_id'])) {
            redirect(aurl(['a' => 'slides']));
        }
        render('slide_form', ['slide' => $slide, 'slider' => slider_by_id((int)$slide['slider_id'])]);

    case 'slide_save':
        $id = (int)($_POST['id'] ?? 0);
        $st = db()->prepare('SELECT * FROM slides WHERE id = ?');
        $st->execute([$id]);
        $existing = $st->fetch();
        if (!$existing) {
            redirect(aurl(['a' => 'slides']));
        }
        $image = $existing['image'];
        $f = files_list('image');
        if ($f) {
            try {
                $r = save_upload($f[0], true, 'slides');
                delete_upload($image);
                $image = $r['filename'];
            } catch (RuntimeException $ex) {
                flash($ex->getMessage(), 'err');
                redirect(aurl(['a' => 'slide_edit', 'id' => $id]));
            }
        }
        db()->prepare('UPDATE slides SET image=?, title=?, text=?, link=?, active=? WHERE id=?')->execute([
            $image, trim((string)($_POST['title'] ?? '')), trim((string)($_POST['text'] ?? '')),
            trim((string)($_POST['link'] ?? '')), isset($_POST['active']) ? 1 : 0, $id,
        ]);
        flash(t('The image was saved.'));
        redirect(aurl(['a' => 'slider_edit', 'id' => $existing['slider_id']]));

    case 'slide_move':
        $st = db()->prepare('SELECT * FROM slides WHERE id = ?');
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $s = $st->fetch();
        if ($s) {
            $st = db()->prepare('SELECT id FROM slides WHERE slider_id = ? ORDER BY position, id');
            $st->execute([$s['slider_id']]);
            $ids = array_map('intval', array_column($st->fetchAll(), 'id'));
            $i = array_search((int)$s['id'], $ids, true);
            $j = ($_POST['dir'] ?? '') === 'up' ? $i - 1 : $i + 1;
            if ($i !== false && isset($ids[$j])) {
                [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
                foreach ($ids as $n => $sid) {
                    db()->prepare('UPDATE slides SET position = ? WHERE id = ?')->execute([$n + 1, $sid]);
                }
            }
            redirect(aurl(['a' => 'slider_edit', 'id' => $s['slider_id']]));
        }
        redirect(aurl(['a' => 'slides']));

    case 'slide_delete':
        $st = db()->prepare('SELECT * FROM slides WHERE id = ?');
        $st->execute([(int)($_POST['id'] ?? 0)]);
        $s = $st->fetch();
        if ($s) {
            delete_upload($s['image']);
            db()->prepare('DELETE FROM slides WHERE id = ?')->execute([$s['id']]);
            flash(t('The image was deleted.'));
            redirect(aurl(['a' => 'slider_edit', 'id' => $s['slider_id']]));
        }
        redirect(aurl(['a' => 'slides']));

    /* ---------- teme ---------- */

    case 'themes':
        render('themes', ['themes' => themes_list(), 'active' => active_theme(), 'zip' => class_exists('ZipArchive')]);

    case 'theme_activate':
        $slug = (string)($_POST['slug'] ?? '');
        if (theme_is_installed($slug)) {
            set_setting('active_theme', $slug);
            flash(t('The theme “%s” is now active.', theme_info($slug)['name']));
        }
        redirect(aurl(['a' => 'themes']));

    case 'theme_duplicate':
        [$slug, $err] = theme_duplicate((string)($_POST['from'] ?? ''), (string)($_POST['name'] ?? ''));
        flash($err ?? t('The new theme was created in themes/%s/ — edit it there, then activate it here.', $slug), $err ? 'err' : 'ok');
        redirect(aurl(['a' => 'themes']));

    case 'theme_install':
        $f = $_FILES['theme_zip'] ?? null;
        if (!$f || ($f['error'] ?? 4) !== UPLOAD_ERR_OK) {
            flash(t('Choose a .zip archive with the theme.'), 'err');
        } elseif (strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION)) !== 'zip') {
            flash(t('The archive must be a .zip file.'), 'err');
        } else {
            [$slug, $err] = theme_install_zip((string)$f['tmp_name']);
            flash($err ?? t('The theme “%s” was installed. You can activate it from the list.', theme_info($slug)['name']), $err ? 'err' : 'ok');
        }
        redirect(aurl(['a' => 'themes']));

    case 'theme_delete':
        $slug = (string)($_POST['slug'] ?? '');
        if ($slug === 'default') {
            flash(t('The default theme cannot be deleted.'), 'err');
        } elseif ($slug === active_theme()) {
            flash(t('You cannot delete the active theme. Activate another one first.'), 'err');
        } elseif (theme_is_installed($slug)) {
            rrmdir(themes_dir() . '/' . $slug);
            flash(t('The theme was deleted.'));
        }
        redirect(aurl(['a' => 'themes']));

    /* ---------- aspect (culori) ---------- */

    case 'theme':
        render('theme', [
            'groups'  => theme_schema(),
            'values'  => theme_values(),
            'presets' => theme_presets(),
        ]);

    case 'theme_save':
        $over = theme_from_post((array)($_POST['t'] ?? []));
        set_setting('theme', json_encode($over, JSON_UNESCAPED_UNICODE | JSON_FORCE_OBJECT));
        flash($over ? t('The appearance was saved.') : t('The appearance was saved (default colors).'));
        redirect(aurl(['a' => 'theme']));

    /* ---------- setări ---------- */

    case 'settings':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $known = known_langs();
            $chosen = array_keys(langs());
            $def = (string)($_POST['default_lang'] ?? '');
            set_setting('default_lang', in_array($def, $chosen, true) ? $def : default_lang());
            i18n_lang(admin_ui_lang());   // interfața trece imediat la noua limbă implicită
            foreach ($known as $code => $_) {
                if (isset($_POST['site_name'][$code])) {
                    set_setting('site_name_' . $code, trim((string)$_POST['site_name'][$code]));
                    set_setting('tagline_' . $code, trim((string)($_POST['tagline'][$code] ?? '')));
                    set_setting('footer_html_' . $code, trim((string)($_POST['footer_html'][$code] ?? '')));
                    set_setting('footer_' . $code, '');   // vechiul text simplu a fost preluat în conținutul subsolului
                    set_setting('keywords_' . $code, normalize_keywords((string)($_POST['keywords'][$code] ?? '')));
                }
            }
            // Harta din subsol (coordonatele pot fi lipite împreună, ca din Google Maps: „44.4268, 26.1025”)
            $latRaw = trim((string)($_POST['map_lat'] ?? ''));
            $lngRaw = trim((string)($_POST['map_lng'] ?? ''));
            if ($lngRaw === '' && preg_match('~^(-?\d+(?:[.,]\d+)?)\s*[;, ]\s*(-?\d+(?:[.,]\d+)?)$~', $latRaw, $m)) {
                [$latRaw, $lngRaw] = [$m[1], $m[2]];
            }
            $lat = parse_coord($latRaw, -90, 90);
            $lng = parse_coord($lngRaw, -180, 180);
            $embedRaw = trim((string)($_POST['map_embed'] ?? ''));
            [$embed, $embedH] = $embedRaw === '' ? ['', null] : parse_map_embed($embedRaw);
            $mapOn = isset($_POST['map_on']);
            if ($embedRaw !== '' && $embed === '') {
                $mapOn = false;
                flash(t('The map code was not recognized. Paste the “Embed a map” code from Google Maps (<iframe …>) or the link from src.'), 'err');
                $mapErr = true;
            } elseif ($mapOn && $embed === '' && ($lat === null || $lng === null)) {
                $mapOn = false;
                flash(t('The map was not enabled: paste the map code or enter valid coordinates (latitude between -90 and 90, longitude between -180 and 180).'), 'err');
                $mapErr = true;
            }
            set_setting('map_embed', $embed);
            if ($embedH !== null) {
                $_POST['map_height'] = (string)$embedH;
            }
            set_setting('map_on', $mapOn ? '1' : '0');
            set_setting('map_lat', $lat === null ? '' : (string)$lat);
            set_setting('map_lng', $lng === null ? '' : (string)$lng);
            set_setting('map_zoom', (string)max(1, min(20, (int)($_POST['map_zoom'] ?? 15))));
            set_setting('map_height', (string)max(150, min(800, (int)($_POST['map_height'] ?? 300))));
            set_setting('url_rewrite', isset($_POST['url_rewrite']) ? '1' : '0');
            ensure_home_pages();
            if (empty($mapErr)) {
                flash(t('The settings were saved.'));
            }
            redirect(aurl(['a' => 'settings']));
        }
        render('settings', ['sliders' => db()->query('SELECT id, name FROM sliders ORDER BY name')->fetchAll()]);

    case 'lang_add':
        $known = known_langs();
        $code = strtolower(trim((string)($_POST['code'] ?? '')));
        $name = trim((string)($_POST['name'] ?? ''));
        $pick = (string)($_POST['pick'] ?? '');
        if ($code === '' && isset($known[$pick])) {
            $code = $pick;            // limbă deja cunoscută (predefinită sau ștearsă anterior)
        }
        if (!valid_lang_code($code)) {
            flash(t('Invalid language code. Use 2–3 lowercase letters, e.g. pl, pt, nl (or pt-br).'), 'err');
            redirect(aurl(['a' => 'settings']) . '#limbi');
        }
        if (isset(langs()[$code])) {
            flash(t('The language is already active.'), 'err');
            redirect(aurl(['a' => 'settings']) . '#limbi');
        }
        if (!isset($known[$code])) {
            if ($name === '') {
                flash(t('Give the language a name (e.g. Polski).'), 'err');
                redirect(aurl(['a' => 'settings']) . '#limbi');
            }
            $custom = custom_langs();
            $custom[$code] = mb_substr($name, 0, 40);
            set_setting('lang_custom', json_encode($custom, JSON_UNESCAPED_UNICODE));
        }
        $active = array_keys(langs());
        $active[] = $code;
        set_setting('languages', implode(',', $active));
        // limba nouă primește numele site-ului din limba implicită, dacă nu are deja unul (cazul readăugării)
        if (setting('site_name_' . $code) === null) {
            set_setting('site_name_' . $code, site_name(default_lang()));
        }
        ensure_home_pages();
        $restored = (int)db()->query('SELECT COUNT(*) AS c FROM pages WHERE lang = ' . db()->quote($code))->fetch()['c'];
        flash(t('The language “%s” was added.', known_langs()[$code] ?? $code) . ($restored > 1 ? ' ' . t('Its earlier content is available again.') : ''));
        redirect(aurl(['a' => 'settings']) . '#limbi');

    case 'lang_remove':
        $code = (string)($_POST['code'] ?? '');
        $active = array_keys(langs());
        if (!in_array($code, $active, true)) {
            redirect(aurl(['a' => 'settings']) . '#limbi');
        }
        if (count($active) < 2) {
            flash(t('At least one language must remain.'), 'err');
            redirect(aurl(['a' => 'settings']) . '#limbi');
        }
        $active = array_values(array_diff($active, [$code]));
        set_setting('languages', implode(',', $active));
        if (default_lang() === $code || setting('default_lang') === $code) {
            set_setting('default_lang', $active[0]);
        }
        flash(t('The language “%s” was removed from the site. Its pages, footer and settings are kept and come back if you add it again.', known_langs()[$code] ?? $code));
        redirect(aurl(['a' => 'settings']) . '#limbi');

    case 'password':
        $st = db()->prepare('SELECT * FROM users WHERE id = ?');
        $st->execute([$_SESSION['uid']]);
        $u = $st->fetch();
        $new = (string)($_POST['new_password'] ?? '');
        if (!$u || !password_verify((string)($_POST['current_password'] ?? ''), $u['password_hash'])) {
            flash(t('The current password is wrong.'), 'err');
        } elseif (mb_strlen($new) < 8) {
            flash(t('The new password must have at least 8 characters.'), 'err');
        } else {
            db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $u['id']]);
            flash(t('The password was changed.'));
        }
        redirect(aurl(['a' => 'settings']));

    default:
        redirect(aurl());
}
