<?php
declare(strict_types=1);

require __DIR__ . '/lib/bootstrap.php';

// Pornim sesiunea doar pentru cei deja autentificați (previzualizare pagini ascunse);
// vizitatorii normali nu primesc cookie, deci pagina rămâne cache-abilă.
if (isset($_COOKIE['litebase'])) {
    session_boot();
}
$isAdmin = logged_in();

// Prima rulare: nu există niciun cont → trimite la configurare
if ((int)db()->query('SELECT COUNT(*) AS c FROM users')->fetch()['c'] === 0) {
    redirect(url('admin/'));
}
ensure_home_pages();

/* ------------------------------------------------------------------ */
/* Tema                                                                */
/* ------------------------------------------------------------------ */

function theme_render(string $view, array $vars): void
{
    extract($vars);
    ob_start();
    require theme_path($view . '.php');
    $content = ob_get_clean();
    require theme_path('layout.php');
    exit;
}

function menu_items(string $lang): array
{
    $idx = pages_index($lang);
    $items = [];
    foreach (children_of($idx, null) as $p) {
        if (!page_is_live($p) || !(int)$p['in_menu']) {
            continue;
        }
        $p['children'] = array_values(array_filter(
            children_of($idx, (int)$p['id']),
            fn($c) => page_is_live($c) && (int)$c['in_menu']
        ));
        $items[] = $p;
    }
    return $items;
}

/** Slidere: imaginile active ale unui slider (gol dacă sliderul nu există sau e dezactivat). */
function slider_slides(int $id): array
{
    if ($id <= 0) {
        return [];
    }
    $st = db()->prepare('SELECT s.* FROM slides s JOIN sliders r ON r.id = s.slider_id WHERE r.id = ? AND r.active = 1 AND s.active = 1 ORDER BY s.position, s.id');
    $st->execute([$id]);
    return $st->fetchAll();
}

function slider_html(int $id, string $extraClass = ''): string
{
    $slides = slider_slides($id);
    if (!$slides) {
        return '';
    }
    $uid = 'sl' . $id . '-' . (++$GLOBALS['__slider_n']);
    ob_start();
    require theme_path('_slider.php');
    return (string)ob_get_clean();
}
$GLOBALS['__slider_n'] = 0;

/** Înlocuiește [slider id=N] din conținut cu sliderul respectiv. */
function apply_shortcodes(string $html): string
{
    return (string)preg_replace_callback(
        '~(?:<p[^>]*>\s*)?\[slider\s+id=(\d+)\](?:\s*</p>)?~i',
        fn($m) => slider_html((int)$m[1], 'inline'),
        $html
    );
}

/** Conținutul subsolului pentru o limbă (HTML); dacă nu e completat, textul simplu din versiunile vechi. */
function footer_html(string $lang): string
{
    $h = trim((string)setting('footer_html_' . $lang, ''));
    if ($h === '') {
        $old = (string)setting('footer_' . $lang, '');
        return $old === '' ? '' : '<p style="text-align:center">' . e($old) . '</p>';
    }
    return apply_shortcodes($h);
}

function short_text(string $html, int $len = 160): string
{
    $t = trim((string)preg_replace('~\s+~u', ' ', strip_tags(preg_replace('~\[slider\s+id=\d+\]~i', '', $html))));
    return mb_strlen($t) > $len ? rtrim(mb_substr($t, 0, $len - 1)) . '…' : $t;
}

/* ------------------------------------------------------------------ */
/* Rutare                                                              */
/* ------------------------------------------------------------------ */

$path = rawurldecode((string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
$base = base_url();
if ($base !== '' && str_starts_with($path, $base)) {
    $path = substr($path, strlen($base));
}
$path = trim($path, '/');
$path = preg_replace('~^index\.php/?~', '', $path);

if ($path === '') {
    redirect(route(default_lang() . '/'));
}

/* --- robots.txt și sitemap.xml --- */
if ($path === 'robots.txt') {
    header('Content-Type: text/plain; charset=utf-8');
    echo "User-agent: *\nDisallow: /admin/\nSitemap: " . abs_url(url('sitemap.xml')) . "\n";
    exit;
}
if ($path === 'sitemap.xml') {
    header('Content-Type: application/xml; charset=utf-8');
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    foreach (langs() as $code => $_) {
        $rows = [];
        if ($h = home_page($code)) {
            $rows[] = $h;
        }
        foreach (page_tree($code, true) as $p) {
            $rows[] = $p;
        }
        foreach ($rows as $p) {
            if (!page_is_live($p)) {
                continue;
            }
            echo '  <url><loc>' . e(abs_url(page_url($p))) . '</loc><lastmod>' . e(substr((string)$p['updated_at'], 0, 10) ?: date('Y-m-d')) . "</lastmod></url>\n";
        }
    }
    echo '</urlset>';
    exit;
}

/* --- pagini --- */
$segs = explode('/', $path);
$lang = array_shift($segs);
$allLangs = langs();

$common = fn(string $l) => [
    'lang'     => $l,
    'siteName' => site_name($l),
    'tagline'  => (string)setting('tagline_' . $l, ''),
    'footer'   => footer_html($l),
    'menu'     => menu_items($l),
    'allLangs' => $allLangs,
    'isAdmin'  => $isAdmin,
];

if (isset($allLangs[$lang])) {
    i18n_lang($lang);
}
if (!isset($allLangs[$lang])) {
    http_response_code(404);
    $l = default_lang();
    i18n_lang($l);
    theme_render('404', $common($l) + [
        'page' => null, 'metaTitle' => t('Page not found') . ' – ' . site_name($l),
        'metaDesc' => '', 'metaKeywords' => '', 'canonical' => '', 'ogImage' => '', 'noindex' => true, 'currentId' => 0,
    ]);
}

$segs = array_values(array_filter($segs, fn($s) => $s !== ''));
$isHome = !$segs;
$page = $isHome ? home_page($lang) : resolve_page($lang, $segs, $isAdmin);

if (!$page) {
    http_response_code(404);
    theme_render('404', $common($lang) + [
        'page' => null, 'metaTitle' => t('Page not found') . ' – ' . site_name($lang),
        'metaDesc' => '', 'metaKeywords' => '', 'canonical' => '', 'ogImage' => '', 'noindex' => true, 'currentId' => 0,
    ]);
}

// Adresa canonică: dacă cineva a deschis pagina cu alt format (ex. majuscule), îl ducem la cea corectă
$canonicalPath = page_url($page);
if (!$isHome && rawurldecode($canonicalPath) !== rawurldecode(route($path))) {
    redirect($canonicalPath);
}

$files   = page_files((int)$page['id']);
$images  = [];   // în galerie (la sfârșitul paginii)
$aligned = [];   // aliniate la stânga / dreapta / centru, în text
$docs    = [];
foreach ($files as $f) {
    if (!(int)$f['is_image']) {
        $docs[] = $f;
    } elseif (in_array($f['align'] ?? 'gallery', ['left', 'right', 'center'], true)) {
        $aligned[] = $f;
    } else {
        $images[] = $f;
    }
}
$firstImage = $aligned[0] ?? $images[0] ?? null;
$slides  = slider_slides((int)($page['slider_id'] ?? 0));   // sliderul de la începutul paginii

$siteName = site_name($lang);
$metaTitle = $page['meta_title'] !== '' ? $page['meta_title']
    : ($isHome ? $siteName . (setting('tagline_' . $lang) ? ' – ' . setting('tagline_' . $lang) : '') : $page['title'] . ' – ' . $siteName);
$metaDesc = $page['meta_description'] !== '' ? $page['meta_description']
    : (short_text((string)$page['content']) ?: (string)setting('tagline_' . $lang, ''));
$metaKeywords = $page['meta_keywords'] !== '' ? (string)$page['meta_keywords'] : (string)setting('keywords_' . $lang, '');
$ogImage = $firstImage ? abs_url(url('uploads/' . $firstImage['filename'])) : ($slides ? abs_url(url('uploads/' . $slides[0]['image'])) : '');

$page['content'] = apply_shortcodes((string)$page['content']);

theme_render($isHome ? 'home' : 'page', $common($lang) + [
    'page'      => $page,
    'currentId' => (int)$page['id'],
    'images'    => $images,
    'aligned'   => $aligned,
    'docs'      => $docs,
    'topSlider' => $slides ? slider_html((int)$page['slider_id']) : '',
    'metaTitle' => $metaTitle,
    'metaDesc'  => $metaDesc,
    'canonical' => abs_url($canonicalPath),
    'ogImage'   => $ogImage,
    'noindex'   => !page_is_live($page),
    'metaKeywords' => $metaKeywords,
]);
